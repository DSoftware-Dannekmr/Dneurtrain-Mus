"""
Complete Musical Genre Database
Contains all genres and subgenres with their musical parameters.
"""
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
from enum import Enum

class TimeSignature(Enum):
    TS_4_4 = (4, 4)
    TS_3_4 = (3, 4)
    TS_6_8 = (6, 8)
    TS_2_4 = (2, 4)
    TS_5_4 = (5, 4)
    TS_7_8 = (7, 8)
    TS_9_8 = (9, 8)
    TS_11_8 = (11, 8)
    TS_12_8 = (12, 8)
    TS_2_2 = (2, 2)
    TS_3_8 = (3, 8)

class ScaleType(Enum):
    MAJOR = "major"
    MINOR = "minor"
    DORIAN = "dorian"
    PHRYGIAN = "phrygian"
    LYDIAN = "lydian"
    MIXOLYDIAN = "mixolydian"
    AEOLIAN = "aeolian"
    LOCRIAN = "locrian"
    HARMONIC_MINOR = "harmonic_minor"
    MELODIC_MINOR = "melodic_minor"
    PENTATONIC_MAJOR = "pentatonic_major"
    PENTATONIC_MINOR = "pentatonic_minor"
    BLUES = "blues"
    WHOLE_TONE = "whole_tone"
    CHROMATIC = "chromatic"
    DIMINISHED = "diminished"
    AUGMENTED = "augmented"
    ARABIC = "arabic"
    HUNGARIAN = "hungarian"
    JAPANESE = "japanese"
    CHINESE = "chinese"
    INDIAN = "indian"
    FLAMENCO = "flamenco"
    KLEZMER = "klezmer"
    GYPSY = "gypsy"
    BEBOP = "bebop"

@dataclass
class GenreParams:
    """Musical parameters for a genre."""
    name: str
    category: str
    tempo_range: Tuple[int, int]  # BPM min, max
    time_signatures: List[TimeSignature]
    scales: List[ScaleType]
    swing: float  # 0.0 = straight, 1.0 = full swing
    velocity_range: Tuple[int, int]
    note_density: float  # 0.0 = sparse, 1.0 = dense
    syncopation: float  # 0.0 = on-beat, 1.0 = highly syncopated
    instruments: List[str]
    drum_pattern: str  # Pattern type identifier
    bass_style: str
    chord_complexity: float  # 0.0 = simple triads, 1.0 = complex extensions
    description: str

# Scale intervals (semitones from root)
SCALE_INTERVALS = {
    ScaleType.MAJOR: [0, 2, 4, 5, 7, 9, 11],
    ScaleType.MINOR: [0, 2, 3, 5, 7, 8, 10],
    ScaleType.DORIAN: [0, 2, 3, 5, 7, 9, 10],
    ScaleType.PHRYGIAN: [0, 1, 3, 5, 7, 8, 10],
    ScaleType.LYDIAN: [0, 2, 4, 6, 7, 9, 11],
    ScaleType.MIXOLYDIAN: [0, 2, 4, 5, 7, 9, 10],
    ScaleType.AEOLIAN: [0, 2, 3, 5, 7, 8, 10],
    ScaleType.LOCRIAN: [0, 1, 3, 5, 6, 8, 10],
    ScaleType.HARMONIC_MINOR: [0, 2, 3, 5, 7, 8, 11],
    ScaleType.MELODIC_MINOR: [0, 2, 3, 5, 7, 9, 11],
    ScaleType.PENTATONIC_MAJOR: [0, 2, 4, 7, 9],
    ScaleType.PENTATONIC_MINOR: [0, 3, 5, 7, 10],
    ScaleType.BLUES: [0, 3, 5, 6, 7, 10],
    ScaleType.WHOLE_TONE: [0, 2, 4, 6, 8, 10],
    ScaleType.CHROMATIC: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    ScaleType.DIMINISHED: [0, 2, 3, 5, 6, 8, 9, 11],
    ScaleType.AUGMENTED: [0, 3, 4, 7, 8, 11],
    ScaleType.ARABIC: [0, 1, 4, 5, 7, 8, 11],  # Hijaz
    ScaleType.HUNGARIAN: [0, 2, 3, 6, 7, 8, 11],
    ScaleType.JAPANESE: [0, 1, 5, 7, 8],  # In scale
    ScaleType.CHINESE: [0, 2, 4, 7, 9],  # Pentatonic
    ScaleType.INDIAN: [0, 1, 4, 5, 7, 8, 10],  # Bhairav
    ScaleType.FLAMENCO: [0, 1, 4, 5, 7, 8, 10],  # Phrygian dominant
    ScaleType.KLEZMER: [0, 1, 4, 5, 7, 8, 10],  # Freygish
    ScaleType.GYPSY: [0, 2, 3, 6, 7, 8, 11],
    ScaleType.BEBOP: [0, 2, 4, 5, 7, 9, 10, 11],
}

def get_scale_notes(root: int, scale_type: ScaleType) -> List[int]:
    """Get all notes in a scale given root note."""
    intervals = SCALE_INTERVALS[scale_type]
    return [root + i for i in intervals]
