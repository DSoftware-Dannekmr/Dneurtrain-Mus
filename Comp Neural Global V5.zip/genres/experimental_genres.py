"""
Experimental, Avant-Garde, and Digital Genres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

EXPERIMENTAL_GENRES = {
    "noise": GenreParams(
        name="Noise", category="Experimental",
        tempo_range=(0, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHROMATIC],
        swing=0.0, velocity_range=(60, 127), note_density=0.8,
        syncopation=0.8, instruments=["noise_generators", "feedback", "electronics"],
        drum_pattern="noise", bass_style="noise_bass", chord_complexity=0.0,
        description="Harsh, atonal sound"
    ),
    "drone": GenreParams(
        name="Drone", category="Experimental",
        tempo_range=(0, 60), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(20, 70), note_density=0.1,
        syncopation=0.0, instruments=["synth", "guitar", "organ"],
        drum_pattern="none", bass_style="drone", chord_complexity=0.2,
        description="Sustained tones"
    ),
    "musique_concrete": GenreParams(
        name="Musique Concrète", category="Experimental",
        tempo_range=(0, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHROMATIC],
        swing=0.0, velocity_range=(20, 100), note_density=0.4,
        syncopation=0.6, instruments=["tape", "samples", "found_sounds"],
        drum_pattern="concrete", bass_style="concrete_bass", chord_complexity=0.5,
        description="Manipulated recordings"
    ),
    "free_improvisation": GenreParams(
        name="Free Improvisation", category="Experimental",
        tempo_range=(0, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHROMATIC],
        swing=0.3, velocity_range=(20, 120), note_density=0.5,
        syncopation=0.7, instruments=["any"],
        drum_pattern="free", bass_style="free", chord_complexity=0.8,
        description="Spontaneous creation"
    ),
    "electroacoustic": GenreParams(
        name="Electroacoustic", category="Experimental",
        tempo_range=(0, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHROMATIC, ScaleType.WHOLE_TONE],
        swing=0.0, velocity_range=(20, 100), note_density=0.4,
        syncopation=0.4, instruments=["electronics", "acoustic_instruments"],
        drum_pattern="electroacoustic", bass_style="electroacoustic_bass", chord_complexity=0.7,
        description="Electronic and acoustic fusion"
    ),
    "avant_prog": GenreParams(
        name="Avant-Prog", category="Experimental",
        tempo_range=(60, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8, TimeSignature.TS_5_4],
        scales=[ScaleType.CHROMATIC, ScaleType.WHOLE_TONE, ScaleType.DIMINISHED],
        swing=0.0, velocity_range=(30, 110), note_density=0.6,
        syncopation=0.6, instruments=["keyboards", "guitar", "bass", "drums"],
        drum_pattern="avant_prog", bass_style="avant_prog_bass", chord_complexity=0.9,
        description="Experimental progressive rock"
    ),
    "glitch": GenreParams(
        name="Glitch", category="Experimental",
        tempo_range=(80, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(40, 100), note_density=0.6,
        syncopation=0.7, instruments=["glitch", "synth", "samples"],
        drum_pattern="glitch", bass_style="glitch_bass", chord_complexity=0.4,
        description="Digital errors as music"
    ),
    "plunderphonics": GenreParams(
        name="Plunderphonics", category="Experimental",
        tempo_range=(60, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(40, 90), note_density=0.5,
        syncopation=0.5, instruments=["samples", "turntables"],
        drum_pattern="plunder", bass_style="plunder_bass", chord_complexity=0.4,
        description="Sample-based collage"
    ),
    "sound_art": GenreParams(
        name="Sound Art", category="Experimental",
        tempo_range=(0, 60), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHROMATIC],
        swing=0.0, velocity_range=(10, 80), note_density=0.2,
        syncopation=0.3, instruments=["installations", "field_recordings", "electronics"],
        drum_pattern="none", bass_style="sound_art_bass", chord_complexity=0.5,
        description="Sonic installations"
    ),
}

DIGITAL_GENRES = {
    "chiptune": GenreParams(
        name="Chiptune", category="Digital",
        tempo_range=(100, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.7,
        syncopation=0.4, instruments=["8bit_synth", "pulse_wave", "noise"],
        drum_pattern="chiptune", bass_style="chiptune_bass", chord_complexity=0.3,
        description="8-bit video game music"
    ),
    "bitpop": GenreParams(
        name="Bitpop", category="Digital",
        tempo_range=(110, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.3, instruments=["8bit_synth", "drums", "bass"],
        drum_pattern="bitpop", bass_style="bitpop_bass", chord_complexity=0.3,
        description="Pop with chiptune elements"
    ),
    "algorave": GenreParams(
        name="Algorave", category="Digital",
        tempo_range=(120, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.5, instruments=["live_coded_synth", "drums"],
        drum_pattern="algorave", bass_style="algorave_bass", chord_complexity=0.4,
        description="Live coded electronic"
    ),
    "generative_music": GenreParams(
        name="Generative Music", category="Digital",
        tempo_range=(60, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(30, 70), note_density=0.4,
        syncopation=0.3, instruments=["synth", "algorithms"],
        drum_pattern="generative", bass_style="generative_bass", chord_complexity=0.5,
        description="Algorithm-created music"
    ),
    "ai_generated": GenreParams(
        name="AI-Generated Music", category="Digital",
        tempo_range=(60, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(40, 100), note_density=0.5,
        syncopation=0.4, instruments=["neural_network", "synth"],
        drum_pattern="ai", bass_style="ai_bass", chord_complexity=0.5,
        description="Machine learning composed"
    ),
    "future_funk": GenreParams(
        name="Future Funk", category="Digital",
        tempo_range=(110, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["samples", "synth", "drums"],
        drum_pattern="future_funk", bass_style="future_funk_bass", chord_complexity=0.4,
        description="Disco-sampled electronic"
    ),
    "chillhop": GenreParams(
        name="Chillhop", category="Digital",
        tempo_range=(70, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.3, velocity_range=(40, 75), note_density=0.4,
        syncopation=0.4, instruments=["drums", "bass", "samples", "piano"],
        drum_pattern="chillhop", bass_style="chillhop_bass", chord_complexity=0.5,
        description="Relaxed hip-hop beats"
    ),
    "vaportrap": GenreParams(
        name="Vaportrap", category="Digital",
        tempo_range=(60, 80), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.1, velocity_range=(50, 85), note_density=0.4,
        syncopation=0.4, instruments=["808", "synth", "samples"],
        drum_pattern="vaportrap", bass_style="vaportrap_bass", chord_complexity=0.3,
        description="Vaporwave meets trap"
    ),
}

SOVIET_RUSSIAN_GENRES = {
    "soviet_rock": GenreParams(
        name="Soviet Rock (Kino style)", category="Russian",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(50, 95), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "synth"],
        drum_pattern="soviet_rock", bass_style="soviet_bass", chord_complexity=0.4,
        description="Viktor Tsoy, post-punk influenced"
    ),
    "russian_post_punk": GenreParams(
        name="Russian Post-Punk", category="Russian",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.4, instruments=["guitar", "bass", "drums", "synth"],
        drum_pattern="russian_post_punk", bass_style="russian_post_punk_bass", chord_complexity=0.4,
        description="Cold wave, dark atmosphere"
    ),
    "russian_chanson": GenreParams(
        name="Russian Chanson", category="Russian",
        tempo_range=(80, 120), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.2, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "accordion", "bass"],
        drum_pattern="chanson", bass_style="chanson_bass", chord_complexity=0.4,
        description="Russian urban folk"
    ),
}
