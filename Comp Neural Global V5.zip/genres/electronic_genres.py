"""
Electronic Music Genres and Subgenres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

ELECTRONIC_GENRES = {
    # === HOUSE ===
    "house": GenreParams(
        name="House", category="Electronic",
        tempo_range=(118, 135), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.1, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.4, instruments=["synth", "drums", "bass", "piano"],
        drum_pattern="four_on_floor", bass_style="house_bass", chord_complexity=0.4,
        description="Four-on-the-floor, Chicago origin"
    ),
    "deep_house": GenreParams(
        name="Deep House", category="Electronic",
        tempo_range=(115, 125), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.5, instruments=["synth_pad", "drums", "bass", "rhodes"],
        drum_pattern="deep_house", bass_style="deep_sub", chord_complexity=0.5,
        description="Soulful, jazzy, atmospheric"
    ),
    "tech_house": GenreParams(
        name="Tech House", category="Electronic",
        tempo_range=(122, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.4, instruments=["synth", "drums", "bass"],
        drum_pattern="tech_house", bass_style="tech_groove", chord_complexity=0.3,
        description="Minimal, groove-focused"
    ),
    "progressive_house": GenreParams(
        name="Progressive House", category="Electronic",
        tempo_range=(126, 132), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.0, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["synth", "drums", "bass", "pads"],
        drum_pattern="prog_house", bass_style="progressive", chord_complexity=0.5,
        description="Building progressions, melodic"
    ),
    "electro_house": GenreParams(
        name="Electro House", category="Electronic",
        tempo_range=(125, 135), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.4, instruments=["synth", "drums", "bass"],
        drum_pattern="electro_house", bass_style="electro_saw", chord_complexity=0.3,
        description="Heavy synths, aggressive"
    ),
    "acid_house": GenreParams(
        name="Acid House", category="Electronic",
        tempo_range=(118, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.1, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["303", "drums", "bass"],
        drum_pattern="acid", bass_style="acid_303", chord_complexity=0.2,
        description="TB-303 squelchy basslines"
    ),
    # === TECHNO ===
    "techno": GenreParams(
        name="Techno", category="Electronic",
        tempo_range=(125, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.4, instruments=["synth", "drums", "bass"],
        drum_pattern="techno", bass_style="techno_sub", chord_complexity=0.2,
        description="Detroit origin, repetitive, hypnotic"
    ),
    "detroit_techno": GenreParams(
        name="Detroit Techno", category="Electronic",
        tempo_range=(125, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.1, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.4, instruments=["synth", "drums", "strings"],
        drum_pattern="detroit", bass_style="detroit_bass", chord_complexity=0.4,
        description="Futuristic, soulful"
    ),
    "minimal_techno": GenreParams(
        name="Minimal Techno", category="Electronic",
        tempo_range=(120, 135), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(60, 90), note_density=0.3,
        syncopation=0.5, instruments=["synth", "drums", "clicks"],
        drum_pattern="minimal", bass_style="minimal_sub", chord_complexity=0.1,
        description="Stripped down, hypnotic"
    ),
    "dub_techno": GenreParams(
        name="Dub Techno", category="Electronic",
        tempo_range=(115, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.1, velocity_range=(50, 85), note_density=0.4,
        syncopation=0.4, instruments=["synth", "drums", "delay", "reverb"],
        drum_pattern="dub_techno", bass_style="dub_sub", chord_complexity=0.3,
        description="Spacious, reverb-heavy, atmospheric"
    ),
    # === TRANCE ===
    "trance": GenreParams(
        name="Trance", category="Electronic",
        tempo_range=(130, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.3, instruments=["synth", "drums", "pads", "arps"],
        drum_pattern="trance", bass_style="trance_rolling", chord_complexity=0.5,
        description="Euphoric, melodic, building"
    ),
    "progressive_trance": GenreParams(
        name="Progressive Trance", category="Electronic",
        tempo_range=(128, 138), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.0, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["synth", "drums", "pads"],
        drum_pattern="prog_trance", bass_style="progressive", chord_complexity=0.5,
        description="Slower builds, deeper"
    ),
    "psytrance": GenreParams(
        name="Psytrance", category="Electronic",
        tempo_range=(140, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PHRYGIAN, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.8,
        syncopation=0.5, instruments=["synth", "drums", "fx"],
        drum_pattern="psytrance", bass_style="psy_rolling", chord_complexity=0.4,
        description="Psychedelic, rolling basslines"
    ),
    "goa_trance": GenreParams(
        name="Goa Trance", category="Electronic",
        tempo_range=(135, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PHRYGIAN, ScaleType.ARABIC],
        swing=0.0, velocity_range=(70, 100), note_density=0.7,
        syncopation=0.4, instruments=["synth", "drums", "ethnic_samples"],
        drum_pattern="goa", bass_style="goa_acid", chord_complexity=0.4,
        description="Indian influence, 303 acid lines"
    ),
    # === DRUM AND BASS ===
    "drum_and_bass": GenreParams(
        name="Drum and Bass", category="Electronic",
        tempo_range=(160, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.7, instruments=["synth", "drums", "bass"],
        drum_pattern="dnb_breakbeat", bass_style="reese", chord_complexity=0.4,
        description="Fast breakbeats, heavy bass"
    ),
    "liquid_dnb": GenreParams(
        name="Liquid DnB", category="Electronic",
        tempo_range=(170, 176), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.1, velocity_range=(60, 100), note_density=0.6,
        syncopation=0.6, instruments=["synth", "drums", "bass", "vocals"],
        drum_pattern="liquid", bass_style="liquid_sub", chord_complexity=0.5,
        description="Melodic, soulful DnB"
    ),
    "neurofunk": GenreParams(
        name="Neurofunk", category="Electronic",
        tempo_range=(172, 178), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(90, 127), note_density=0.8,
        syncopation=0.7, instruments=["synth", "drums", "bass"],
        drum_pattern="neuro", bass_style="neuro_bass", chord_complexity=0.3,
        description="Dark, technical, complex bass"
    ),
    "jungle": GenreParams(
        name="Jungle", category="Electronic",
        tempo_range=(155, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.2, velocity_range=(80, 110), note_density=0.8,
        syncopation=0.8, instruments=["drums", "bass", "samples"],
        drum_pattern="jungle_amen", bass_style="jungle_sub", chord_complexity=0.2,
        description="Chopped breakbeats, ragga influence"
    ),
    # === DUBSTEP ===
    "dubstep": GenreParams(
        name="Dubstep", category="Electronic",
        tempo_range=(138, 142), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 127), note_density=0.5,
        syncopation=0.6, instruments=["synth", "drums", "wobble_bass"],
        drum_pattern="dubstep", bass_style="wobble", chord_complexity=0.2,
        description="Half-time, wobble bass, UK origin"
    ),
    "brostep": GenreParams(
        name="Brostep", category="Electronic",
        tempo_range=(140, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(100, 127), note_density=0.7,
        syncopation=0.5, instruments=["synth", "drums", "growl_bass"],
        drum_pattern="brostep", bass_style="growl", chord_complexity=0.2,
        description="Aggressive, heavy drops"
    ),
    # === AMBIENT / CHILL ===
    "ambient": GenreParams(
        name="Ambient", category="Electronic",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN, ScaleType.MIXOLYDIAN],
        swing=0.0, velocity_range=(20, 70), note_density=0.2,
        syncopation=0.1, instruments=["pads", "textures", "field_recordings"],
        drum_pattern="none", bass_style="drone", chord_complexity=0.6,
        description="Atmospheric, textural, no beat"
    ),
    "dark_ambient": GenreParams(
        name="Dark Ambient", category="Electronic",
        tempo_range=(40, 80), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN, ScaleType.LOCRIAN],
        swing=0.0, velocity_range=(20, 60), note_density=0.1,
        syncopation=0.0, instruments=["drones", "noise", "textures"],
        drum_pattern="none", bass_style="dark_drone", chord_complexity=0.4,
        description="Ominous, unsettling atmospheres"
    ),
    "chillout": GenreParams(
        name="Chillout", category="Electronic",
        tempo_range=(80, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.3, instruments=["synth", "drums", "bass", "guitar"],
        drum_pattern="chill", bass_style="chill_sub", chord_complexity=0.5,
        description="Relaxed, downtempo"
    ),
    "downtempo": GenreParams(
        name="Downtempo", category="Electronic",
        tempo_range=(70, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.3, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.4, instruments=["synth", "drums", "bass", "samples"],
        drum_pattern="downtempo", bass_style="downtempo_groove", chord_complexity=0.5,
        description="Slow, atmospheric, trip-hop adjacent"
    ),
    "trip_hop": GenreParams(
        name="Trip-Hop", category="Electronic",
        tempo_range=(70, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.BLUES],
        swing=0.3, velocity_range=(40, 85), note_density=0.4,
        syncopation=0.5, instruments=["drums", "bass", "samples", "strings"],
        drum_pattern="trip_hop", bass_style="trip_hop_bass", chord_complexity=0.5,
        description="Bristol sound, cinematic, dark"
    ),
    # === OTHER ELECTRONIC ===
    "synthwave": GenreParams(
        name="Synthwave", category="Electronic",
        tempo_range=(80, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.2, instruments=["analog_synth", "drums", "bass"],
        drum_pattern="synthwave", bass_style="synthwave_bass", chord_complexity=0.4,
        description="80s nostalgia, retro synths"
    ),
    "vaporwave": GenreParams(
        name="Vaporwave", category="Electronic",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN],
        swing=0.2, velocity_range=(40, 70), note_density=0.3,
        syncopation=0.2, instruments=["samples", "synth", "slowed_audio"],
        drum_pattern="vaporwave", bass_style="slowed", chord_complexity=0.4,
        description="Slowed samples, 80s/90s nostalgia"
    ),
    "idm": GenreParams(
        name="IDM", category="Electronic",
        tempo_range=(80, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_5_4, TimeSignature.TS_7_8],
        scales=[ScaleType.MINOR, ScaleType.LYDIAN, ScaleType.WHOLE_TONE],
        swing=0.0, velocity_range=(40, 100), note_density=0.6,
        syncopation=0.7, instruments=["synth", "glitch", "drums"],
        drum_pattern="idm_glitch", bass_style="idm_bass", chord_complexity=0.7,
        description="Intelligent dance music, experimental"
    ),
    "breakbeat": GenreParams(
        name="Breakbeat", category="Electronic",
        tempo_range=(120, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.2, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.7, instruments=["drums", "bass", "synth"],
        drum_pattern="breakbeat", bass_style="breakbeat_bass", chord_complexity=0.3,
        description="Broken beats, funk influence"
    ),
    "hardcore_techno": GenreParams(
        name="Hardcore Techno", category="Electronic",
        tempo_range=(160, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(100, 127), note_density=0.8,
        syncopation=0.3, instruments=["synth", "drums", "distorted_kick"],
        drum_pattern="hardcore", bass_style="hardcore_bass", chord_complexity=0.2,
        description="Fast, aggressive, distorted kicks"
    ),
    "gabber": GenreParams(
        name="Gabber", category="Electronic",
        tempo_range=(150, 190), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(110, 127), note_density=0.8,
        syncopation=0.2, instruments=["distorted_kick", "synth"],
        drum_pattern="gabber", bass_style="gabber_kick", chord_complexity=0.1,
        description="Dutch hardcore, distorted kicks"
    ),
    "future_bass": GenreParams(
        name="Future Bass", category="Electronic",
        tempo_range=(130, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN],
        swing=0.1, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "supersaws", "vocals"],
        drum_pattern="future_bass", bass_style="future_bass", chord_complexity=0.6,
        description="Colorful, emotional, supersaw chords"
    ),
    "tropical_house": GenreParams(
        name="Tropical House", category="Electronic",
        tempo_range=(100, 115), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(60, 90), note_density=0.5,
        syncopation=0.4, instruments=["marimba", "steel_drums", "synth", "drums"],
        drum_pattern="tropical", bass_style="tropical_bass", chord_complexity=0.4,
        description="Summery, relaxed house"
    ),
    "moombahton": GenreParams(
        name="Moombahton", category="Electronic",
        tempo_range=(108, 112), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.2, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass"],
        drum_pattern="moombahton", bass_style="moombah_bass", chord_complexity=0.3,
        description="Dutch house meets reggaeton"
    ),
    "chillwave": GenreParams(
        name="Chillwave", category="Electronic",
        tempo_range=(80, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(40, 75), note_density=0.4,
        syncopation=0.3, instruments=["synth", "drums", "guitar", "vocals"],
        drum_pattern="chillwave", bass_style="chillwave_bass", chord_complexity=0.4,
        description="Lo-fi, dreamy, nostalgic"
    ),
    "witch_house": GenreParams(
        name="Witch House", category="Electronic",
        tempo_range=(60, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(40, 80), note_density=0.3,
        syncopation=0.4, instruments=["synth", "drums", "samples", "vocals"],
        drum_pattern="witch_house", bass_style="witch_bass", chord_complexity=0.3,
        description="Dark, occult, chopped samples"
    ),
}
