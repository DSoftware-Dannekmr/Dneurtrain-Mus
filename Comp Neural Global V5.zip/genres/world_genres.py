"""
World Music Genres - Traditional and Folk from around the globe
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

WORLD_GENRES = {
    # === AFRICAN ===
    "afrobeat": GenreParams(
        name="Afrobeat", category="African",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN, ScaleType.PENTATONIC_MINOR],
        swing=0.3, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.7, instruments=["drums", "bass", "guitar", "horns", "keyboards", "percussion"],
        drum_pattern="afrobeat", bass_style="afrobeat_bass", chord_complexity=0.5,
        description="Nigerian funk-jazz fusion"
    ),
    "afropop": GenreParams(
        name="Afropop", category="African",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.PENTATONIC_MAJOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["guitar", "bass", "drums", "synth"],
        drum_pattern="afropop", bass_style="afropop_bass", chord_complexity=0.4,
        description="Modern African pop"
    ),
    "highlife": GenreParams(
        name="Highlife", category="African",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.3, velocity_range=(60, 95), note_density=0.6,
        syncopation=0.5, instruments=["guitar", "bass", "horns", "drums"],
        drum_pattern="highlife", bass_style="highlife_bass", chord_complexity=0.4,
        description="Ghanaian dance music"
    ),
    "soukous": GenreParams(
        name="Soukous", category="African",
        tempo_range=(120, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.PENTATONIC_MAJOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.7,
        syncopation=0.6, instruments=["guitar", "bass", "drums", "horns"],
        drum_pattern="soukous", bass_style="soukous_bass", chord_complexity=0.3,
        description="Congolese rumba"
    ),
    "kizomba": GenreParams(
        name="Kizomba", category="African",
        tempo_range=(80, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.2, velocity_range=(50, 85), note_density=0.4,
        syncopation=0.4, instruments=["synth", "drums", "bass", "guitar"],
        drum_pattern="kizomba", bass_style="kizomba_bass", chord_complexity=0.3,
        description="Angolan romantic dance"
    ),
    "amapiano": GenreParams(
        name="Amapiano", category="African",
        tempo_range=(110, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(60, 95), note_density=0.5,
        syncopation=0.5, instruments=["piano", "bass", "drums", "shaker"],
        drum_pattern="amapiano", bass_style="amapiano_bass", chord_complexity=0.4,
        description="South African house-jazz"
    ),
    "gqom": GenreParams(
        name="Gqom", category="African",
        tempo_range=(120, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass"],
        drum_pattern="gqom", bass_style="gqom_bass", chord_complexity=0.2,
        description="South African electronic"
    ),
    "mbalax": GenreParams(
        name="Mbalax", category="African",
        tempo_range=(110, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MAJOR, ScaleType.MAJOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.7,
        syncopation=0.7, instruments=["sabar", "guitar", "bass", "keyboards"],
        drum_pattern="mbalax", bass_style="mbalax_bass", chord_complexity=0.3,
        description="Senegalese popular music"
    ),
    "afroswing": GenreParams(
        name="Afroswing", category="African",
        tempo_range=(95, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.2, velocity_range=(60, 95), note_density=0.5,
        syncopation=0.5, instruments=["synth", "drums", "bass"],
        drum_pattern="afroswing", bass_style="afroswing_bass", chord_complexity=0.3,
        description="UK Afrobeats fusion"
    ),
    # === MIDDLE EASTERN / ARABIC ===
    "arabic_classical": GenreParams(
        name="Arabic Classical", category="Middle Eastern",
        tempo_range=(60, 120), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_12_8],
        scales=[ScaleType.ARABIC, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(40, 90), note_density=0.5,
        syncopation=0.4, instruments=["oud", "qanun", "ney", "riq", "tabla"],
        drum_pattern="arabic", bass_style="arabic_bass", chord_complexity=0.6,
        description="Traditional Arabic maqam music"
    ),
    "shaabi": GenreParams(
        name="Shaabi", category="Middle Eastern",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.ARABIC, ScaleType.MINOR],
        swing=0.1, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.5, instruments=["synth", "tabla", "accordion", "bass"],
        drum_pattern="shaabi", bass_style="shaabi_bass", chord_complexity=0.3,
        description="Egyptian popular music"
    ),
    "mahraganat": GenreParams(
        name="Mahraganat", category="Middle Eastern",
        tempo_range=(120, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.ARABIC, ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 120), note_density=0.7,
        syncopation=0.5, instruments=["synth", "drums", "bass", "autotune"],
        drum_pattern="mahraganat", bass_style="mahraganat_bass", chord_complexity=0.2,
        description="Egyptian electronic street music"
    ),
    "raqs_sharqi": GenreParams(
        name="Raqs Sharqi (Belly Dance)", category="Middle Eastern",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.ARABIC, ScaleType.HARMONIC_MINOR],
        swing=0.1, velocity_range=(60, 100), note_density=0.6,
        syncopation=0.5, instruments=["oud", "violin", "tabla", "accordion"],
        drum_pattern="baladi", bass_style="oriental_bass", chord_complexity=0.4,
        description="Oriental dance music"
    ),
    # === INDIAN ===
    "hindustani_classical": GenreParams(
        name="Hindustani Classical", category="Indian",
        tempo_range=(40, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8],
        scales=[ScaleType.INDIAN],
        swing=0.0, velocity_range=(30, 100), note_density=0.5,
        syncopation=0.4, instruments=["sitar", "tabla", "tanpura", "sarangi"],
        drum_pattern="taal", bass_style="drone", chord_complexity=0.7,
        description="North Indian classical"
    ),
    "carnatic": GenreParams(
        name="Carnatic", category="Indian",
        tempo_range=(60, 200), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8],
        scales=[ScaleType.INDIAN],
        swing=0.0, velocity_range=(40, 100), note_density=0.6,
        syncopation=0.5, instruments=["veena", "mridangam", "violin", "ghatam"],
        drum_pattern="carnatic_taal", bass_style="carnatic_drone", chord_complexity=0.7,
        description="South Indian classical"
    ),
    "bollywood": GenreParams(
        name="Bollywood", category="Indian",
        tempo_range=(90, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.INDIAN, ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.1, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.4, instruments=["strings", "tabla", "synth", "drums", "bass"],
        drum_pattern="bollywood", bass_style="bollywood_bass", chord_complexity=0.5,
        description="Indian film music"
    ),
    "bhangra": GenreParams(
        name="Bhangra", category="Indian",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(80, 110), note_density=0.7,
        syncopation=0.5, instruments=["dhol", "tumbi", "synth", "bass"],
        drum_pattern="bhangra", bass_style="bhangra_bass", chord_complexity=0.3,
        description="Punjabi dance music"
    ),
    # === EUROPEAN FOLK ===
    "flamenco": GenreParams(
        name="Flamenco", category="European",
        tempo_range=(60, 200), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4, TimeSignature.TS_12_8],
        scales=[ScaleType.FLAMENCO, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(40, 120), note_density=0.6,
        syncopation=0.6, instruments=["flamenco_guitar", "cajon", "palmas", "castanets"],
        drum_pattern="flamenco", bass_style="flamenco_bass", chord_complexity=0.5,
        description="Spanish Andalusian music"
    ),
    "fado": GenreParams(
        name="Fado", category="European",
        tempo_range=(60, 90), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_2_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.1, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.3, instruments=["portuguese_guitar", "classical_guitar", "bass"],
        drum_pattern="fado", bass_style="fado_bass", chord_complexity=0.5,
        description="Portuguese melancholic song"
    ),
    "celtic": GenreParams(
        name="Celtic", category="European",
        tempo_range=(80, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_6_8, TimeSignature.TS_9_8],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN, ScaleType.MAJOR],
        swing=0.2, velocity_range=(50, 100), note_density=0.6,
        syncopation=0.4, instruments=["fiddle", "tin_whistle", "bodhran", "harp", "uilleann_pipes"],
        drum_pattern="celtic", bass_style="celtic_bass", chord_complexity=0.4,
        description="Irish/Scottish traditional"
    ),
    "balkan": GenreParams(
        name="Balkan", category="European",
        tempo_range=(100, 200), time_signatures=[TimeSignature.TS_7_8, TimeSignature.TS_9_8, TimeSignature.TS_11_8],
        scales=[ScaleType.GYPSY, ScaleType.HARMONIC_MINOR, ScaleType.PHRYGIAN],
        swing=0.1, velocity_range=(70, 120), note_density=0.7,
        syncopation=0.6, instruments=["brass", "accordion", "clarinet", "drums"],
        drum_pattern="balkan", bass_style="balkan_bass", chord_complexity=0.5,
        description="Southeastern European brass"
    ),
    "klezmer": GenreParams(
        name="Klezmer", category="European",
        tempo_range=(80, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_2_4],
        scales=[ScaleType.KLEZMER, ScaleType.HARMONIC_MINOR],
        swing=0.3, velocity_range=(50, 110), note_density=0.6,
        syncopation=0.5, instruments=["clarinet", "violin", "accordion", "bass", "drums"],
        drum_pattern="klezmer", bass_style="klezmer_bass", chord_complexity=0.5,
        description="Jewish Eastern European"
    ),
    "polka": GenreParams(
        name="Polka", category="European",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_2_4],
        scales=[ScaleType.MAJOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.2, instruments=["accordion", "tuba", "clarinet", "drums"],
        drum_pattern="polka", bass_style="oom_pah", chord_complexity=0.2,
        description="Central European dance"
    ),
    # === ASIAN ===
    "japanese_traditional": GenreParams(
        name="Japanese Traditional", category="Asian",
        tempo_range=(40, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.JAPANESE],
        swing=0.0, velocity_range=(30, 80), note_density=0.3,
        syncopation=0.2, instruments=["koto", "shakuhachi", "shamisen", "taiko"],
        drum_pattern="japanese", bass_style="japanese_bass", chord_complexity=0.4,
        description="Traditional Japanese music"
    ),
    "enka": GenreParams(
        name="Enka", category="Asian",
        tempo_range=(60, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.JAPANESE, ScaleType.PENTATONIC_MINOR],
        swing=0.1, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.2, instruments=["strings", "shamisen", "drums", "synth"],
        drum_pattern="enka", bass_style="enka_bass", chord_complexity=0.4,
        description="Japanese ballad style"
    ),
    "chinese_traditional": GenreParams(
        name="Chinese Traditional", category="Asian",
        tempo_range=(50, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHINESE, ScaleType.PENTATONIC_MAJOR],
        swing=0.0, velocity_range=(30, 80), note_density=0.4,
        syncopation=0.2, instruments=["erhu", "pipa", "guzheng", "dizi"],
        drum_pattern="chinese", bass_style="chinese_bass", chord_complexity=0.4,
        description="Traditional Chinese music"
    ),
    "cantopop": GenreParams(
        name="Cantopop", category="Asian",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(60, 95), note_density=0.5,
        syncopation=0.3, instruments=["synth", "drums", "bass", "strings"],
        drum_pattern="cantopop", bass_style="cantopop_bass", chord_complexity=0.4,
        description="Hong Kong pop music"
    ),
    # === CARIBBEAN ===
    "reggae": GenreParams(
        name="Reggae", category="Caribbean",
        tempo_range=(60, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(50, 85), note_density=0.5,
        syncopation=0.6, instruments=["guitar", "bass", "drums", "organ", "horns"],
        drum_pattern="one_drop", bass_style="reggae_bass", chord_complexity=0.3,
        description="Jamaican roots music"
    ),
    "dub": GenreParams(
        name="Dub", category="Caribbean",
        tempo_range=(60, 85), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.2, velocity_range=(50, 90), note_density=0.4,
        syncopation=0.5, instruments=["bass", "drums", "delay", "reverb"],
        drum_pattern="dub", bass_style="dub_bass", chord_complexity=0.2,
        description="Reggae remix style"
    ),
    "dancehall": GenreParams(
        name="Dancehall", category="Caribbean",
        tempo_range=(90, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.1, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass"],
        drum_pattern="dancehall", bass_style="dancehall_bass", chord_complexity=0.2,
        description="Jamaican electronic dance"
    ),
    "calypso": GenreParams(
        name="Calypso", category="Caribbean",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR],
        swing=0.3, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["steel_pan", "guitar", "bass", "drums"],
        drum_pattern="calypso", bass_style="calypso_bass", chord_complexity=0.3,
        description="Trinidad carnival music"
    ),
    "soca": GenreParams(
        name="Soca", category="Caribbean",
        tempo_range=(130, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR],
        swing=0.1, velocity_range=(80, 110), note_density=0.7,
        syncopation=0.5, instruments=["synth", "drums", "bass", "brass"],
        drum_pattern="soca", bass_style="soca_bass", chord_complexity=0.3,
        description="Soul of calypso"
    ),
}
