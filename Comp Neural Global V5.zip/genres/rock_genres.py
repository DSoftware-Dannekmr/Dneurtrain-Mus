"""
Rock Genres and Subgenres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

ROCK_GENRES = {
    # === ROCK PRINCIPAL ===
    "rock_and_roll": GenreParams(
        name="Rock and Roll", category="Rock",
        tempo_range=(120, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.PENTATONIC_MAJOR, ScaleType.BLUES],
        swing=0.3, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.4, instruments=["electric_guitar", "bass", "drums", "piano"],
        drum_pattern="rock_basic", bass_style="walking", chord_complexity=0.2,
        description="Classic 1950s rock with blues influence"
    ),
    "hard_rock": GenreParams(
        name="Hard Rock", category="Rock",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MINOR, ScaleType.BLUES, ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 127), note_density=0.7,
        syncopation=0.3, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="rock_heavy", bass_style="root_fifth", chord_complexity=0.3,
        description="Heavy, distorted guitar-driven rock"
    ),
    "punk_rock": GenreParams(
        name="Punk Rock", category="Rock",
        tempo_range=(150, 220), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 127), note_density=0.8,
        syncopation=0.2, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="punk_fast", bass_style="root_eighth", chord_complexity=0.1,
        description="Fast, aggressive, simple chord progressions"
    ),
    "grunge": GenreParams(
        name="Grunge", category="Rock",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.PENTATONIC_MINOR],
        swing=0.0, velocity_range=(60, 120), note_density=0.5,
        syncopation=0.4, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="grunge", bass_style="heavy_root", chord_complexity=0.3,
        description="Dark, heavy, Seattle sound"
    ),
    "indie_rock": GenreParams(
        name="Indie Rock", category="Rock",
        tempo_range=(100, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.1, velocity_range=(50, 100), note_density=0.5,
        syncopation=0.4, instruments=["clean_guitar", "bass", "drums", "synth"],
        drum_pattern="indie", bass_style="melodic", chord_complexity=0.5,
        description="Alternative, lo-fi aesthetic"
    ),
    "progressive_rock": GenreParams(
        name="Progressive Rock", category="Rock",
        tempo_range=(60, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8, TimeSignature.TS_5_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.LYDIAN, ScaleType.MIXOLYDIAN],
        swing=0.0, velocity_range=(40, 110), note_density=0.6,
        syncopation=0.5, instruments=["keyboards", "guitar", "bass", "drums", "mellotron"],
        drum_pattern="prog_complex", bass_style="melodic_complex", chord_complexity=0.8,
        description="Complex structures, odd time signatures"
    ),
    "glam_rock": GenreParams(
        name="Glam Rock", category="Rock",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.3, instruments=["electric_guitar", "bass", "drums", "piano", "strings"],
        drum_pattern="glam_stomp", bass_style="driving", chord_complexity=0.4,
        description="Theatrical, catchy, 70s style"
    ),
    "alternative_rock": GenreParams(
        name="Alternative Rock", category="Rock",
        tempo_range=(90, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.0, velocity_range=(50, 110), note_density=0.5,
        syncopation=0.4, instruments=["guitar", "bass", "drums", "synth"],
        drum_pattern="alternative", bass_style="melodic", chord_complexity=0.5,
        description="Non-mainstream rock sound"
    ),
    "psychedelic_rock": GenreParams(
        name="Psychedelic Rock", category="Rock",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MIXOLYDIAN, ScaleType.DORIAN, ScaleType.PENTATONIC_MINOR],
        swing=0.2, velocity_range=(40, 100), note_density=0.5,
        syncopation=0.5, instruments=["guitar", "bass", "drums", "organ", "sitar"],
        drum_pattern="psychedelic", bass_style="droning", chord_complexity=0.6,
        description="Trippy, experimental 60s sound"
    ),
    "garage_rock": GenreParams(
        name="Garage Rock", category="Rock",
        tempo_range=(120, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MINOR, ScaleType.BLUES],
        swing=0.1, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.3, instruments=["distorted_guitar", "bass", "drums", "organ"],
        drum_pattern="garage", bass_style="simple", chord_complexity=0.2,
        description="Raw, lo-fi, energetic"
    ),
    "post_rock": GenreParams(
        name="Post-Rock", category="Rock",
        tempo_range=(60, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_6_8],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(30, 110), note_density=0.4,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "strings", "synth"],
        drum_pattern="post_rock", bass_style="ambient", chord_complexity=0.6,
        description="Atmospheric, instrumental, crescendos"
    ),
    "shoegaze": GenreParams(
        name="Shoegaze", category="Rock",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.0, velocity_range=(40, 90), note_density=0.6,
        syncopation=0.2, instruments=["guitar", "bass", "drums", "synth"],
        drum_pattern="shoegaze", bass_style="droning", chord_complexity=0.4,
        description="Wall of sound, ethereal vocals"
    ),
    "britpop": GenreParams(
        name="Britpop", category="Rock",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.1, velocity_range=(60, 100), note_density=0.6,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "keyboards"],
        drum_pattern="britpop", bass_style="melodic", chord_complexity=0.4,
        description="British guitar pop, 90s"
    ),
    "emo": GenreParams(
        name="Emo", category="Rock",
        tempo_range=(100, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(50, 120), note_density=0.6,
        syncopation=0.4, instruments=["guitar", "bass", "drums"],
        drum_pattern="emo", bass_style="melodic", chord_complexity=0.5,
        description="Emotional, confessional lyrics"
    ),
    "post_grunge": GenreParams(
        name="Post-Grunge", category="Rock",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(60, 110), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "bass", "drums"],
        drum_pattern="post_grunge", bass_style="heavy", chord_complexity=0.3,
        description="Commercial grunge derivative"
    ),
    "stoner_rock": GenreParams(
        name="Stoner Rock", category="Rock",
        tempo_range=(60, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MINOR, ScaleType.BLUES, ScaleType.DORIAN],
        swing=0.2, velocity_range=(70, 110), note_density=0.5,
        syncopation=0.4, instruments=["heavy_guitar", "bass", "drums"],
        drum_pattern="stoner", bass_style="heavy_groove", chord_complexity=0.3,
        description="Heavy, fuzzy, psychedelic"
    ),
    "southern_rock": GenreParams(
        name="Southern Rock", category="Rock",
        tempo_range=(90, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MAJOR, ScaleType.MIXOLYDIAN, ScaleType.BLUES],
        swing=0.3, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.4, instruments=["guitar", "slide_guitar", "bass", "drums", "piano"],
        drum_pattern="southern", bass_style="country_rock", chord_complexity=0.3,
        description="Blues-influenced American South rock"
    ),
    "art_rock": GenreParams(
        name="Art Rock", category="Rock",
        tempo_range=(60, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_5_4, TimeSignature.TS_7_8],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.LYDIAN, ScaleType.WHOLE_TONE],
        swing=0.0, velocity_range=(30, 100), note_density=0.5,
        syncopation=0.5, instruments=["keyboards", "guitar", "bass", "drums", "orchestra"],
        drum_pattern="art_rock", bass_style="experimental", chord_complexity=0.8,
        description="Experimental, avant-garde rock"
    ),
    "surf_rock": GenreParams(
        name="Surf Rock", category="Rock",
        tempo_range=(130, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.0, velocity_range=(70, 100), note_density=0.7,
        syncopation=0.3, instruments=["reverb_guitar", "bass", "drums"],
        drum_pattern="surf", bass_style="driving", chord_complexity=0.2,
        description="Reverb-heavy, California sound"
    ),
    "blues_rock": GenreParams(
        name="Blues Rock", category="Rock",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_12_8],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MINOR, ScaleType.MIXOLYDIAN],
        swing=0.4, velocity_range=(60, 110), note_density=0.5,
        syncopation=0.5, instruments=["guitar", "bass", "drums", "harmonica"],
        drum_pattern="blues_rock", bass_style="blues_walking", chord_complexity=0.4,
        description="Blues-influenced rock"
    ),
}
