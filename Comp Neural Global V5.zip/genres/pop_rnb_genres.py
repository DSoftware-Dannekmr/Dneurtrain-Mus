"""
Pop, R&B, Soul, and Funk Genres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

POP_GENRES = {
    "pop": GenreParams(
        name="Pop", category="Pop",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.3, instruments=["synth", "drums", "bass", "guitar", "vocals"],
        drum_pattern="pop_basic", bass_style="pop_bass", chord_complexity=0.4,
        description="Mainstream, catchy, radio-friendly"
    ),
    "synthpop": GenreParams(
        name="Synthpop", category="Pop",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.3, instruments=["synth", "drum_machine", "bass_synth"],
        drum_pattern="synthpop", bass_style="synth_bass", chord_complexity=0.4,
        description="Electronic, 80s influenced"
    ),
    "electropop": GenreParams(
        name="Electropop", category="Pop",
        tempo_range=(110, 135), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.4, instruments=["synth", "drums", "bass", "vocoder"],
        drum_pattern="electropop", bass_style="electro_bass", chord_complexity=0.4,
        description="Electronic dance-pop"
    ),
    "dance_pop": GenreParams(
        name="Dance Pop", category="Pop",
        tempo_range=(115, 135), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.4, instruments=["synth", "drums", "bass"],
        drum_pattern="dance_pop", bass_style="dance_bass", chord_complexity=0.3,
        description="Club-oriented pop"
    ),
    "teen_pop": GenreParams(
        name="Teen Pop", category="Pop",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.2, instruments=["synth", "drums", "bass", "guitar"],
        drum_pattern="teen_pop", bass_style="simple_pop", chord_complexity=0.2,
        description="Youth-oriented, simple melodies"
    ),
    "indie_pop": GenreParams(
        name="Indie Pop", category="Pop",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "synth", "drums", "bass"],
        drum_pattern="indie_pop", bass_style="indie_bass", chord_complexity=0.5,
        description="Alternative, lo-fi aesthetic"
    ),
    "dream_pop": GenreParams(
        name="Dream Pop", category="Pop",
        tempo_range=(80, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.2, instruments=["guitar", "synth", "drums", "reverb"],
        drum_pattern="dream_pop", bass_style="ethereal", chord_complexity=0.5,
        description="Atmospheric, ethereal, reverb-heavy"
    ),
    "kpop": GenreParams(
        name="K-Pop", category="Pop",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.7,
        syncopation=0.4, instruments=["synth", "drums", "bass", "strings"],
        drum_pattern="kpop", bass_style="kpop_bass", chord_complexity=0.5,
        description="Korean pop, highly produced"
    ),
    "jpop": GenreParams(
        name="J-Pop", category="Pop",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.3, instruments=["synth", "drums", "bass", "guitar"],
        drum_pattern="jpop", bass_style="jpop_bass", chord_complexity=0.5,
        description="Japanese pop, melodic"
    ),
    "latin_pop": GenreParams(
        name="Latin Pop", category="Pop",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["guitar", "drums", "bass", "percussion"],
        drum_pattern="latin_pop", bass_style="latin_bass", chord_complexity=0.4,
        description="Spanish/Portuguese influenced pop"
    ),
    "bedroom_pop": GenreParams(
        name="Bedroom Pop", category="Pop",
        tempo_range=(80, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.3, instruments=["guitar", "synth", "drums", "lo-fi"],
        drum_pattern="bedroom", bass_style="lo-fi_bass", chord_complexity=0.4,
        description="Lo-fi, DIY, intimate"
    ),
    "hyperpop": GenreParams(
        name="Hyperpop", category="Pop",
        tempo_range=(130, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 127), note_density=0.8,
        syncopation=0.5, instruments=["synth", "autotune", "glitch", "bass"],
        drum_pattern="hyperpop", bass_style="hyperpop_bass", chord_complexity=0.4,
        description="Maximalist, distorted, experimental"
    ),
}

RNB_GENRES = {
    "rnb": GenreParams(
        name="R&B", category="R&B",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.PENTATONIC_MINOR],
        swing=0.3, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.5, instruments=["keys", "bass", "drums", "guitar"],
        drum_pattern="rnb", bass_style="rnb_groove", chord_complexity=0.6,
        description="Rhythm and blues, soulful"
    ),
    "contemporary_rnb": GenreParams(
        name="Contemporary R&B", category="R&B",
        tempo_range=(70, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.5, instruments=["synth", "drums", "bass", "samples"],
        drum_pattern="contemporary_rnb", bass_style="modern_rnb", chord_complexity=0.6,
        description="Modern R&B, electronic influenced"
    ),
    "new_jack_swing": GenreParams(
        name="New Jack Swing", category="R&B",
        tempo_range=(95, 115), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.3, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.6, instruments=["synth", "drums", "bass", "samples"],
        drum_pattern="new_jack", bass_style="new_jack_bass", chord_complexity=0.5,
        description="Hip-hop influenced R&B, 80s-90s"
    ),
    "alternative_rnb": GenreParams(
        name="Alternative R&B", category="R&B",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.PHRYGIAN],
        swing=0.2, velocity_range=(40, 85), note_density=0.4,
        syncopation=0.5, instruments=["synth", "drums", "bass", "textures"],
        drum_pattern="alt_rnb", bass_style="alt_rnb_bass", chord_complexity=0.6,
        description="Experimental, atmospheric R&B"
    ),
}

SOUL_GENRES = {
    "soul": GenreParams(
        name="Soul", category="Soul",
        tempo_range=(70, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR, ScaleType.BLUES],
        swing=0.4, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.5, instruments=["organ", "guitar", "bass", "drums", "horns"],
        drum_pattern="soul", bass_style="soul_groove", chord_complexity=0.5,
        description="Emotional, gospel-influenced"
    ),
    "motown": GenreParams(
        name="Motown", category="Soul",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.3, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.4, instruments=["bass", "drums", "strings", "horns", "piano"],
        drum_pattern="motown", bass_style="motown_bass", chord_complexity=0.4,
        description="Detroit sound, polished production"
    ),
    "neo_soul": GenreParams(
        name="Neo-Soul", category="Soul",
        tempo_range=(70, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.PENTATONIC_MINOR],
        swing=0.3, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.5, instruments=["rhodes", "bass", "drums", "guitar"],
        drum_pattern="neo_soul", bass_style="neo_soul_bass", chord_complexity=0.7,
        description="Modern soul, jazz influenced"
    ),
    "southern_soul": GenreParams(
        name="Southern Soul", category="Soul",
        tempo_range=(70, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.BLUES],
        swing=0.4, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.5, instruments=["organ", "guitar", "bass", "drums", "horns"],
        drum_pattern="southern_soul", bass_style="southern_groove", chord_complexity=0.4,
        description="Memphis/Muscle Shoals sound"
    ),
    "psychedelic_soul": GenreParams(
        name="Psychedelic Soul", category="Soul",
        tempo_range=(80, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.3, velocity_range=(50, 100), note_density=0.6,
        syncopation=0.5, instruments=["wah_guitar", "bass", "drums", "strings", "synth"],
        drum_pattern="psych_soul", bass_style="psych_groove", chord_complexity=0.5,
        description="Trippy, experimental soul"
    ),
}

FUNK_GENRES = {
    "funk": GenreParams(
        name="Funk", category="Funk",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.7, instruments=["bass", "drums", "guitar", "horns", "clavinet"],
        drum_pattern="funk", bass_style="slap_funk", chord_complexity=0.4,
        description="Groove-based, syncopated"
    ),
    "p_funk": GenreParams(
        name="P-Funk", category="Funk",
        tempo_range=(90, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.7, instruments=["bass", "drums", "synth", "guitar", "horns"],
        drum_pattern="p_funk", bass_style="p_funk_bass", chord_complexity=0.4,
        description="Parliament-Funkadelic style"
    ),
    "funk_rock": GenreParams(
        name="Funk Rock", category="Funk",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.1, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.6, instruments=["bass", "drums", "guitar"],
        drum_pattern="funk_rock", bass_style="slap_rock", chord_complexity=0.3,
        description="Funk meets rock energy"
    ),
    "electro_funk": GenreParams(
        name="Electro-Funk", category="Funk",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.1, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.6, instruments=["synth", "drum_machine", "bass_synth", "vocoder"],
        drum_pattern="electro_funk", bass_style="synth_funk", chord_complexity=0.4,
        description="Electronic funk, 80s influenced"
    ),
    "boogie": GenreParams(
        name="Boogie", category="Funk",
        tempo_range=(110, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["synth", "bass", "drums", "guitar"],
        drum_pattern="boogie", bass_style="boogie_bass", chord_complexity=0.5,
        description="Post-disco, electronic funk"
    ),
}
