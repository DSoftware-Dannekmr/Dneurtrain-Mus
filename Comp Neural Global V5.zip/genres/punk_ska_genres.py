"""
Punk, Ska, and Industrial Genres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

PUNK_GENRES = {
    "punk": GenreParams(
        name="Punk", category="Punk",
        tempo_range=(150, 220), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 127), note_density=0.8,
        syncopation=0.2, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="punk", bass_style="punk_bass", chord_complexity=0.1,
        description="Fast, aggressive, simple"
    ),
    "hardcore_punk": GenreParams(
        name="Hardcore Punk", category="Punk",
        tempo_range=(160, 240), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(100, 127), note_density=0.9,
        syncopation=0.3, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="hardcore", bass_style="hardcore_bass", chord_complexity=0.1,
        description="Extreme speed and aggression"
    ),
    "post_punk": GenreParams(
        name="Post-Punk", category="Punk",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.4, instruments=["guitar", "bass", "drums", "synth"],
        drum_pattern="post_punk", bass_style="post_punk_bass", chord_complexity=0.4,
        description="Art-influenced, atmospheric"
    ),
    "pop_punk": GenreParams(
        name="Pop Punk", category="Punk",
        tempo_range=(140, 190), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.7,
        syncopation=0.2, instruments=["guitar", "bass", "drums"],
        drum_pattern="pop_punk", bass_style="pop_punk_bass", chord_complexity=0.2,
        description="Melodic, catchy punk"
    ),
    "skate_punk": GenreParams(
        name="Skate Punk", category="Punk",
        tempo_range=(160, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 120), note_density=0.8,
        syncopation=0.2, instruments=["guitar", "bass", "drums"],
        drum_pattern="skate_punk", bass_style="skate_punk_bass", chord_complexity=0.2,
        description="Fast melodic punk"
    ),
    "oi": GenreParams(
        name="Oi!", category="Punk",
        tempo_range=(130, 170), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 120), note_density=0.7,
        syncopation=0.2, instruments=["guitar", "bass", "drums"],
        drum_pattern="oi", bass_style="oi_bass", chord_complexity=0.1,
        description="Working class punk"
    ),
    "anarcho_punk": GenreParams(
        name="Anarcho-Punk", category="Punk",
        tempo_range=(140, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 120), note_density=0.7,
        syncopation=0.3, instruments=["guitar", "bass", "drums"],
        drum_pattern="anarcho", bass_style="anarcho_bass", chord_complexity=0.2,
        description="Political, DIY ethic"
    ),
    "crust_punk": GenreParams(
        name="Crust Punk", category="Punk",
        tempo_range=(140, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(100, 127), note_density=0.8,
        syncopation=0.3, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="crust", bass_style="crust_bass", chord_complexity=0.2,
        description="Metal-influenced punk"
    ),
    "garage_punk": GenreParams(
        name="Garage Punk", category="Punk",
        tempo_range=(140, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MINOR, ScaleType.BLUES],
        swing=0.1, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "organ"],
        drum_pattern="garage_punk", bass_style="garage_punk_bass", chord_complexity=0.2,
        description="Raw, lo-fi punk"
    ),
}

SKA_GENRES = {
    "ska": GenreParams(
        name="Ska", category="Ska",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.6, instruments=["guitar", "bass", "drums", "horns", "organ"],
        drum_pattern="ska", bass_style="ska_bass", chord_complexity=0.3,
        description="Jamaican upbeat rhythm"
    ),
    "two_tone": GenreParams(
        name="2 Tone", category="Ska",
        tempo_range=(120, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["guitar", "bass", "drums", "horns", "organ"],
        drum_pattern="two_tone", bass_style="two_tone_bass", chord_complexity=0.3,
        description="British ska revival"
    ),
    "ska_punk": GenreParams(
        name="Ska Punk", category="Ska",
        tempo_range=(150, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.5, instruments=["guitar", "bass", "drums", "horns"],
        drum_pattern="ska_punk", bass_style="ska_punk_bass", chord_complexity=0.2,
        description="Ska meets punk energy"
    ),
    "rocksteady": GenreParams(
        name="Rocksteady", category="Ska",
        tempo_range=(70, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.3, velocity_range=(50, 80), note_density=0.5,
        syncopation=0.5, instruments=["guitar", "bass", "drums", "organ", "horns"],
        drum_pattern="rocksteady", bass_style="rocksteady_bass", chord_complexity=0.3,
        description="Slower ska precursor to reggae"
    ),
}

INDUSTRIAL_GENRES = {
    "industrial": GenreParams(
        name="Industrial", category="Industrial",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 127), note_density=0.6,
        syncopation=0.4, instruments=["synth", "drums", "noise", "samples"],
        drum_pattern="industrial", bass_style="industrial_bass", chord_complexity=0.3,
        description="Mechanical, abrasive"
    ),
    "industrial_rock": GenreParams(
        name="Industrial Rock", category="Industrial",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 127), note_density=0.7,
        syncopation=0.4, instruments=["guitar", "synth", "drums", "samples"],
        drum_pattern="industrial_rock", bass_style="industrial_rock_bass", chord_complexity=0.3,
        description="NIN, Ministry style"
    ),
    "darkwave": GenreParams(
        name="Darkwave", category="Industrial",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.3, instruments=["synth", "drums", "bass"],
        drum_pattern="darkwave", bass_style="darkwave_bass", chord_complexity=0.4,
        description="Dark synth-based"
    ),
    "ebm": GenreParams(
        name="EBM", category="Industrial",
        tempo_range=(110, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.3, instruments=["synth", "drum_machine", "bass_synth"],
        drum_pattern="ebm", bass_style="ebm_bass", chord_complexity=0.2,
        description="Electronic body music"
    ),
    "aggrotech": GenreParams(
        name="Aggrotech", category="Industrial",
        tempo_range=(130, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(90, 127), note_density=0.7,
        syncopation=0.4, instruments=["synth", "drums", "distorted_vocals"],
        drum_pattern="aggrotech", bass_style="aggrotech_bass", chord_complexity=0.2,
        description="Aggressive electronic"
    ),
    "power_noise": GenreParams(
        name="Power Noise", category="Industrial",
        tempo_range=(130, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.CHROMATIC],
        swing=0.0, velocity_range=(100, 127), note_density=0.8,
        syncopation=0.5, instruments=["noise", "distorted_drums", "synth"],
        drum_pattern="power_noise", bass_style="noise_bass", chord_complexity=0.1,
        description="Harsh, rhythmic noise"
    ),
}
