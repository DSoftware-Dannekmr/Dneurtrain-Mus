"""
Latin Music Genres and Subgenres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

LATIN_GENRES = {
    "salsa": GenreParams(
        name="Salsa", category="Latin",
        tempo_range=(150, 250), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.1, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.7, instruments=["piano", "bass", "congas", "timbales", "horns", "bongos"],
        drum_pattern="salsa_clave", bass_style="tumbao", chord_complexity=0.5,
        description="Afro-Cuban dance music"
    ),
    "bachata": GenreParams(
        name="Bachata", category="Latin",
        tempo_range=(120, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(60, 90), note_density=0.5,
        syncopation=0.4, instruments=["requinto", "guitar", "bass", "bongos", "guira"],
        drum_pattern="bachata", bass_style="bachata_bass", chord_complexity=0.3,
        description="Dominican romantic music"
    ),
    "merengue": GenreParams(
        name="Merengue", category="Latin",
        tempo_range=(130, 180), time_signatures=[TimeSignature.TS_2_4],
        scales=[ScaleType.MAJOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.7,
        syncopation=0.4, instruments=["accordion", "tambora", "guira", "bass", "saxophone"],
        drum_pattern="merengue", bass_style="merengue_bass", chord_complexity=0.3,
        description="Dominican fast dance music"
    ),
    "cumbia": GenreParams(
        name="Cumbia", category="Latin",
        tempo_range=(80, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(60, 90), note_density=0.5,
        syncopation=0.5, instruments=["accordion", "drums", "bass", "guacharaca"],
        drum_pattern="cumbia", bass_style="cumbia_bass", chord_complexity=0.3,
        description="Colombian folk dance"
    ),
    "reggaeton": GenreParams(
        name="Reggaetón", category="Latin",
        tempo_range=(85, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass"],
        drum_pattern="dembow", bass_style="reggaeton_bass", chord_complexity=0.2,
        description="Puerto Rican urban music"
    ),
    "bolero": GenreParams(
        name="Bolero", category="Latin",
        tempo_range=(60, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(40, 75), note_density=0.4,
        syncopation=0.3, instruments=["guitar", "bass", "bongos", "strings"],
        drum_pattern="bolero", bass_style="bolero_bass", chord_complexity=0.5,
        description="Romantic ballad style"
    ),
    "son_cubano": GenreParams(
        name="Son Cubano", category="Latin",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(60, 95), note_density=0.6,
        syncopation=0.6, instruments=["tres", "bass", "bongos", "maracas", "claves"],
        drum_pattern="son_clave", bass_style="son_bass", chord_complexity=0.4,
        description="Traditional Cuban music"
    ),
    "tango": GenreParams(
        name="Tango", category="Latin",
        tempo_range=(60, 80), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_2_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(50, 100), note_density=0.5,
        syncopation=0.5, instruments=["bandoneon", "violin", "piano", "bass"],
        drum_pattern="tango", bass_style="tango_bass", chord_complexity=0.6,
        description="Argentine dramatic dance"
    ),
    "nortena": GenreParams(
        name="Norteña", category="Latin",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.4, instruments=["accordion", "bajo_sexto", "bass", "drums"],
        drum_pattern="nortena", bass_style="nortena_bass", chord_complexity=0.3,
        description="Northern Mexican folk"
    ),
    "banda": GenreParams(
        name="Banda", category="Latin",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(80, 110), note_density=0.7,
        syncopation=0.4, instruments=["brass", "clarinets", "tuba", "drums"],
        drum_pattern="banda", bass_style="tuba_bass", chord_complexity=0.3,
        description="Mexican brass band"
    ),
    "corrido": GenreParams(
        name="Corrido", category="Latin",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_3_4, TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(60, 90), note_density=0.5,
        syncopation=0.3, instruments=["accordion", "guitar", "bass", "drums"],
        drum_pattern="corrido", bass_style="corrido_bass", chord_complexity=0.3,
        description="Mexican narrative ballad"
    ),
    "ranchera": GenreParams(
        name="Ranchera", category="Latin",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_3_4, TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["mariachi", "guitar", "violin", "trumpet"],
        drum_pattern="ranchera", bass_style="ranchera_bass", chord_complexity=0.3,
        description="Mexican country music"
    ),
    "mariachi": GenreParams(
        name="Mariachi", category="Latin",
        tempo_range=(80, 160), time_signatures=[TimeSignature.TS_3_4, TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.4, instruments=["violin", "trumpet", "guitar", "vihuela", "guitarron"],
        drum_pattern="mariachi", bass_style="guitarron", chord_complexity=0.4,
        description="Traditional Mexican ensemble"
    ),
    "bossa_nova": GenreParams(
        name="Bossa Nova", category="Latin",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.DORIAN, ScaleType.LYDIAN],
        swing=0.2, velocity_range=(40, 75), note_density=0.5,
        syncopation=0.5, instruments=["nylon_guitar", "bass", "drums", "piano"],
        drum_pattern="bossa", bass_style="bossa_bass", chord_complexity=0.7,
        description="Brazilian jazz-influenced"
    ),
    "samba": GenreParams(
        name="Samba", category="Latin",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_2_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.3, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.7, instruments=["surdo", "tamborim", "cuica", "cavaquinho", "guitar"],
        drum_pattern="samba", bass_style="samba_bass", chord_complexity=0.4,
        description="Brazilian carnival music"
    ),
    "forró": GenreParams(
        name="Forró", category="Latin",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_2_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["accordion", "zabumba", "triangle", "bass"],
        drum_pattern="forro", bass_style="forro_bass", chord_complexity=0.3,
        description="Brazilian northeastern dance"
    ),
    "baile_funk": GenreParams(
        name="Baile Funk", category="Latin",
        tempo_range=(130, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 120), note_density=0.7,
        syncopation=0.6, instruments=["808", "synth", "samples"],
        drum_pattern="baile_funk", bass_style="funk_carioca", chord_complexity=0.2,
        description="Brazilian electronic funk"
    ),
    "vallenato": GenreParams(
        name="Vallenato", category="Latin",
        tempo_range=(100, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR],
        swing=0.2, velocity_range=(60, 95), note_density=0.6,
        syncopation=0.5, instruments=["accordion", "caja", "guacharaca", "bass"],
        drum_pattern="vallenato", bass_style="vallenato_bass", chord_complexity=0.3,
        description="Colombian accordion music"
    ),
    "champeta": GenreParams(
        name="Champeta", category="Latin",
        tempo_range=(100, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.6, instruments=["synth", "drums", "bass", "african_percussion"],
        drum_pattern="champeta", bass_style="champeta_bass", chord_complexity=0.3,
        description="Afro-Colombian electronic"
    ),
    "electrocumbia": GenreParams(
        name="Electrocumbia", category="Latin",
        tempo_range=(90, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass", "samples"],
        drum_pattern="electrocumbia", bass_style="electro_cumbia", chord_complexity=0.3,
        description="Electronic cumbia fusion"
    ),
}
