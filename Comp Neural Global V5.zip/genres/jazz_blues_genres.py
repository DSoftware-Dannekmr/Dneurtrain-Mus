"""
Jazz and Blues Genres and Subgenres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

JAZZ_GENRES = {
    "bebop": GenreParams(
        name="Bebop", category="Jazz",
        tempo_range=(160, 280), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.BEBOP, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.6, velocity_range=(50, 100), note_density=0.8,
        syncopation=0.7, instruments=["saxophone", "trumpet", "piano", "bass", "drums"],
        drum_pattern="bebop", bass_style="walking", chord_complexity=0.9,
        description="Fast, complex, virtuosic improvisation"
    ),
    "cool_jazz": GenreParams(
        name="Cool Jazz", category="Jazz",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.LYDIAN, ScaleType.MAJOR],
        swing=0.4, velocity_range=(40, 80), note_density=0.5,
        syncopation=0.4, instruments=["trumpet", "saxophone", "piano", "bass", "drums"],
        drum_pattern="cool_jazz", bass_style="walking_soft", chord_complexity=0.7,
        description="Relaxed, understated, West Coast"
    ),
    "free_jazz": GenreParams(
        name="Free Jazz", category="Jazz",
        tempo_range=(60, 200), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_5_4],
        scales=[ScaleType.CHROMATIC, ScaleType.WHOLE_TONE],
        swing=0.3, velocity_range=(30, 120), note_density=0.6,
        syncopation=0.8, instruments=["saxophone", "trumpet", "piano", "bass", "drums"],
        drum_pattern="free", bass_style="free", chord_complexity=0.9,
        description="Avant-garde, no fixed structure"
    ),
    "jazz_fusion": GenreParams(
        name="Jazz Fusion", category="Jazz",
        tempo_range=(90, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8],
        scales=[ScaleType.DORIAN, ScaleType.LYDIAN, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(60, 110), note_density=0.7,
        syncopation=0.6, instruments=["electric_guitar", "keyboards", "bass", "drums", "saxophone"],
        drum_pattern="fusion", bass_style="fusion_groove", chord_complexity=0.8,
        description="Jazz meets rock, electric instruments"
    ),
    "smooth_jazz": GenreParams(
        name="Smooth Jazz", category="Jazz",
        tempo_range=(80, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.3, velocity_range=(50, 85), note_density=0.5,
        syncopation=0.4, instruments=["saxophone", "keyboards", "bass", "drums", "guitar"],
        drum_pattern="smooth", bass_style="smooth_groove", chord_complexity=0.5,
        description="Polished, radio-friendly, melodic"
    ),
    "acid_jazz": GenreParams(
        name="Acid Jazz", category="Jazz",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN, ScaleType.BLUES],
        swing=0.3, velocity_range=(60, 100), note_density=0.6,
        syncopation=0.5, instruments=["organ", "guitar", "bass", "drums", "horns"],
        drum_pattern="acid_jazz", bass_style="funk_jazz", chord_complexity=0.6,
        description="Funk, soul, and jazz fusion"
    ),
    "swing": GenreParams(
        name="Swing", category="Jazz",
        tempo_range=(120, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.7, velocity_range=(60, 100), note_density=0.6,
        syncopation=0.5, instruments=["big_band", "brass", "saxophone", "piano", "bass", "drums"],
        drum_pattern="swing", bass_style="walking_swing", chord_complexity=0.5,
        description="Big band era, danceable"
    ),
    "dixieland": GenreParams(
        name="Dixieland", category="Jazz",
        tempo_range=(100, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_2_4],
        scales=[ScaleType.MAJOR, ScaleType.BLUES],
        swing=0.5, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.5, instruments=["trumpet", "clarinet", "trombone", "piano", "banjo", "drums"],
        drum_pattern="dixieland", bass_style="tuba_style", chord_complexity=0.4,
        description="New Orleans traditional jazz"
    ),
    "latin_jazz": GenreParams(
        name="Latin Jazz", category="Jazz",
        tempo_range=(100, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN, ScaleType.HARMONIC_MINOR],
        swing=0.2, velocity_range=(70, 110), note_density=0.7,
        syncopation=0.7, instruments=["piano", "bass", "congas", "timbales", "horns"],
        drum_pattern="latin_clave", bass_style="tumbao", chord_complexity=0.6,
        description="Afro-Cuban rhythms with jazz harmony"
    ),
    "modal_jazz": GenreParams(
        name="Modal Jazz", category="Jazz",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.PHRYGIAN, ScaleType.LYDIAN, ScaleType.MIXOLYDIAN],
        swing=0.4, velocity_range=(40, 90), note_density=0.5,
        syncopation=0.4, instruments=["saxophone", "trumpet", "piano", "bass", "drums"],
        drum_pattern="modal", bass_style="pedal_tone", chord_complexity=0.6,
        description="Based on modes rather than chord changes"
    ),
    "hard_bop": GenreParams(
        name="Hard Bop", category="Jazz",
        tempo_range=(120, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.BLUES, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.5, velocity_range=(60, 110), note_density=0.7,
        syncopation=0.6, instruments=["saxophone", "trumpet", "piano", "bass", "drums"],
        drum_pattern="hard_bop", bass_style="walking_hard", chord_complexity=0.8,
        description="Blues and gospel influenced bebop"
    ),
    "post_bop": GenreParams(
        name="Post-Bop", category="Jazz",
        tempo_range=(80, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.DORIAN, ScaleType.LYDIAN, ScaleType.DIMINISHED],
        swing=0.4, velocity_range=(40, 100), note_density=0.6,
        syncopation=0.6, instruments=["saxophone", "trumpet", "piano", "bass", "drums"],
        drum_pattern="post_bop", bass_style="modern_walking", chord_complexity=0.8,
        description="Modern jazz, expanded harmony"
    ),
    "gypsy_jazz": GenreParams(
        name="Gypsy Jazz", category="Jazz",
        tempo_range=(140, 240), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.GYPSY, ScaleType.HARMONIC_MINOR, ScaleType.MINOR],
        swing=0.5, velocity_range=(60, 100), note_density=0.8,
        syncopation=0.4, instruments=["acoustic_guitar", "violin", "bass", "rhythm_guitar"],
        drum_pattern="la_pompe", bass_style="gypsy_walking", chord_complexity=0.6,
        description="Django Reinhardt style, acoustic"
    ),
    "nu_jazz": GenreParams(
        name="Nu Jazz", category="Jazz",
        tempo_range=(90, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(50, 95), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass", "saxophone", "samples"],
        drum_pattern="nu_jazz", bass_style="electronic_jazz", chord_complexity=0.6,
        description="Electronic and jazz fusion"
    ),
    "ethno_jazz": GenreParams(
        name="Ethno Jazz", category="Jazz",
        tempo_range=(80, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_6_8],
        scales=[ScaleType.DORIAN, ScaleType.ARABIC, ScaleType.INDIAN],
        swing=0.3, velocity_range=(50, 100), note_density=0.6,
        syncopation=0.5, instruments=["world_instruments", "jazz_ensemble"],
        drum_pattern="world_jazz", bass_style="world_bass", chord_complexity=0.6,
        description="World music meets jazz"
    ),
}

BLUES_GENRES = {
    "delta_blues": GenreParams(
        name="Delta Blues", category="Blues",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_12_8],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MINOR],
        swing=0.5, velocity_range=(40, 90), note_density=0.4,
        syncopation=0.5, instruments=["acoustic_guitar", "harmonica", "vocals"],
        drum_pattern="none", bass_style="acoustic_bass", chord_complexity=0.2,
        description="Mississippi Delta, raw acoustic"
    ),
    "chicago_blues": GenreParams(
        name="Chicago Blues", category="Blues",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_12_8],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MINOR],
        swing=0.4, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.5, instruments=["electric_guitar", "harmonica", "piano", "bass", "drums"],
        drum_pattern="chicago_shuffle", bass_style="blues_walking", chord_complexity=0.3,
        description="Electric, urban blues"
    ),
    "electric_blues": GenreParams(
        name="Electric Blues", category="Blues",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_12_8],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MINOR, ScaleType.MIXOLYDIAN],
        swing=0.4, velocity_range=(60, 110), note_density=0.6,
        syncopation=0.5, instruments=["electric_guitar", "bass", "drums", "organ"],
        drum_pattern="electric_blues", bass_style="blues_groove", chord_complexity=0.3,
        description="Amplified, modern blues"
    ),
    "country_blues": GenreParams(
        name="Country Blues", category="Blues",
        tempo_range=(70, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MAJOR],
        swing=0.4, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.4, instruments=["acoustic_guitar", "harmonica"],
        drum_pattern="none", bass_style="fingerpicking", chord_complexity=0.2,
        description="Rural, acoustic, folk influenced"
    ),
    "jump_blues": GenreParams(
        name="Jump Blues", category="Blues",
        tempo_range=(120, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.BLUES, ScaleType.MAJOR],
        swing=0.5, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.5, instruments=["saxophone", "piano", "bass", "drums", "guitar"],
        drum_pattern="jump", bass_style="walking_jump", chord_complexity=0.3,
        description="Upbeat, horn-driven, proto-R&B"
    ),
    "texas_blues": GenreParams(
        name="Texas Blues", category="Blues",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_12_8],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MINOR],
        swing=0.4, velocity_range=(60, 110), note_density=0.5,
        syncopation=0.5, instruments=["electric_guitar", "bass", "drums", "horns"],
        drum_pattern="texas_shuffle", bass_style="texas_groove", chord_complexity=0.3,
        description="Smooth, horn arrangements"
    ),
    "piedmont_blues": GenreParams(
        name="Piedmont Blues", category="Blues",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.BLUES, ScaleType.PENTATONIC_MAJOR],
        swing=0.4, velocity_range=(50, 90), note_density=0.6,
        syncopation=0.5, instruments=["acoustic_guitar"],
        drum_pattern="none", bass_style="fingerpicking_bass", chord_complexity=0.3,
        description="East Coast, ragtime influenced"
    ),
    "west_coast_blues": GenreParams(
        name="West Coast Blues", category="Blues",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.BLUES, ScaleType.MIXOLYDIAN],
        swing=0.4, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.4, instruments=["electric_guitar", "piano", "bass", "drums"],
        drum_pattern="west_coast", bass_style="smooth_blues", chord_complexity=0.4,
        description="Smooth, jazz-influenced"
    ),
}
