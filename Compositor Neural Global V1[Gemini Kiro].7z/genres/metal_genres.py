"""
Metal Genres and Subgenres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

METAL_GENRES = {
    "heavy_metal": GenreParams(
        name="Heavy Metal", category="Metal",
        tempo_range=(100, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(80, 127), note_density=0.7,
        syncopation=0.3, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="metal_basic", bass_style="root_power", chord_complexity=0.3,
        description="Classic metal with power chords"
    ),
    "thrash_metal": GenreParams(
        name="Thrash Metal", category="Metal",
        tempo_range=(150, 220), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN, ScaleType.LOCRIAN],
        swing=0.0, velocity_range=(100, 127), note_density=0.9,
        syncopation=0.4, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="thrash", bass_style="fast_picking", chord_complexity=0.4,
        description="Fast, aggressive, palm-muted riffs"
    ),
    "death_metal": GenreParams(
        name="Death Metal", category="Metal",
        tempo_range=(120, 250), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PHRYGIAN, ScaleType.LOCRIAN, ScaleType.DIMINISHED],
        swing=0.0, velocity_range=(100, 127), note_density=0.9,
        syncopation=0.5, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="death_blast", bass_style="technical", chord_complexity=0.5,
        description="Extreme, blast beats, growling"
    ),
    "black_metal": GenreParams(
        name="Black Metal", category="Metal",
        tempo_range=(140, 220), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(90, 127), note_density=0.8,
        syncopation=0.3, instruments=["tremolo_guitar", "bass", "drums", "keyboards"],
        drum_pattern="black_blast", bass_style="tremolo", chord_complexity=0.4,
        description="Tremolo picking, shrieking vocals"
    ),
    "doom_metal": GenreParams(
        name="Doom Metal", category="Metal",
        tempo_range=(40, 80), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN, ScaleType.LOCRIAN],
        swing=0.0, velocity_range=(70, 110), note_density=0.3,
        syncopation=0.2, instruments=["heavy_guitar", "bass", "drums"],
        drum_pattern="doom_slow", bass_style="droning", chord_complexity=0.3,
        description="Slow, heavy, dark atmosphere"
    ),
    "power_metal": GenreParams(
        name="Power Metal", category="Metal",
        tempo_range=(140, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(80, 120), note_density=0.7,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "keyboards", "choir"],
        drum_pattern="power_double", bass_style="galloping", chord_complexity=0.5,
        description="Epic, melodic, double bass drums"
    ),
    "symphonic_metal": GenreParams(
        name="Symphonic Metal", category="Metal",
        tempo_range=(100, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_6_8],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR, ScaleType.MAJOR],
        swing=0.0, velocity_range=(60, 120), note_density=0.7,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "orchestra", "choir", "keyboards"],
        drum_pattern="symphonic", bass_style="orchestral", chord_complexity=0.7,
        description="Orchestral arrangements, operatic vocals"
    ),
    "progressive_metal": GenreParams(
        name="Progressive Metal", category="Metal",
        tempo_range=(80, 200), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8, TimeSignature.TS_5_4],
        scales=[ScaleType.MINOR, ScaleType.LYDIAN, ScaleType.MIXOLYDIAN, ScaleType.DIMINISHED],
        swing=0.0, velocity_range=(50, 120), note_density=0.7,
        syncopation=0.6, instruments=["guitar", "bass", "drums", "keyboards"],
        drum_pattern="prog_metal", bass_style="technical", chord_complexity=0.8,
        description="Complex structures, technical proficiency"
    ),
    "nu_metal": GenreParams(
        name="Nu Metal", category="Metal",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 120), note_density=0.6,
        syncopation=0.5, instruments=["7string_guitar", "bass", "drums", "turntables", "samples"],
        drum_pattern="nu_metal", bass_style="groove", chord_complexity=0.3,
        description="Hip-hop influenced, downtuned"
    ),
    "groove_metal": GenreParams(
        name="Groove Metal", category="Metal",
        tempo_range=(90, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN, ScaleType.BLUES],
        swing=0.1, velocity_range=(90, 127), note_density=0.6,
        syncopation=0.5, instruments=["distorted_guitar", "bass", "drums"],
        drum_pattern="groove", bass_style="synced_riff", chord_complexity=0.3,
        description="Mid-tempo, heavy grooves"
    ),
    "melodic_death_metal": GenreParams(
        name="Melodic Death Metal", category="Metal",
        tempo_range=(120, 200), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(90, 127), note_density=0.8,
        syncopation=0.4, instruments=["guitar", "bass", "drums", "keyboards"],
        drum_pattern="melodeath", bass_style="melodic_fast", chord_complexity=0.5,
        description="Melodic guitar harmonies with death metal"
    ),
    "folk_metal": GenreParams(
        name="Folk Metal", category="Metal",
        tempo_range=(100, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_6_8, TimeSignature.TS_3_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(70, 120), note_density=0.6,
        syncopation=0.4, instruments=["guitar", "bass", "drums", "violin", "flute", "accordion"],
        drum_pattern="folk_metal", bass_style="folk_driven", chord_complexity=0.5,
        description="Folk instruments and melodies with metal"
    ),
    "industrial_metal": GenreParams(
        name="Industrial Metal", category="Metal",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(90, 127), note_density=0.7,
        syncopation=0.4, instruments=["guitar", "bass", "drums", "synth", "samples"],
        drum_pattern="industrial", bass_style="mechanical", chord_complexity=0.3,
        description="Electronic elements, mechanical rhythms"
    ),
    "sludge_metal": GenreParams(
        name="Sludge Metal", category="Metal",
        tempo_range=(50, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.BLUES, ScaleType.PHRYGIAN],
        swing=0.2, velocity_range=(80, 127), note_density=0.4,
        syncopation=0.3, instruments=["heavy_guitar", "bass", "drums"],
        drum_pattern="sludge", bass_style="heavy_slow", chord_complexity=0.3,
        description="Slow, heavy, Southern influence"
    ),
    "djent": GenreParams(
        name="Djent", category="Metal",
        tempo_range=(100, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_7_8],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(80, 127), note_density=0.7,
        syncopation=0.7, instruments=["8string_guitar", "bass", "drums"],
        drum_pattern="djent", bass_style="polyrhythmic", chord_complexity=0.6,
        description="Polyrhythmic, palm-muted, extended range"
    ),
    "gothic_metal": GenreParams(
        name="Gothic Metal", category="Metal",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(50, 110), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "keyboards", "strings"],
        drum_pattern="gothic", bass_style="atmospheric", chord_complexity=0.5,
        description="Dark, romantic, atmospheric"
    ),
    "speed_metal": GenreParams(
        name="Speed Metal", category="Metal",
        tempo_range=(160, 240), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(100, 127), note_density=0.9,
        syncopation=0.3, instruments=["guitar", "bass", "drums"],
        drum_pattern="speed", bass_style="fast_root", chord_complexity=0.4,
        description="Extremely fast, technical"
    ),
    "crossover_thrash": GenreParams(
        name="Crossover Thrash", category="Metal",
        tempo_range=(160, 220), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.0, velocity_range=(100, 127), note_density=0.8,
        syncopation=0.4, instruments=["guitar", "bass", "drums"],
        drum_pattern="crossover", bass_style="punk_metal", chord_complexity=0.2,
        description="Thrash metal meets hardcore punk"
    ),
}
