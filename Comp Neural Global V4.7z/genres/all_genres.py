"""
Complete Genre Registry - All Musical Genres Combined
"""
from typing import Dict, Optional, List
from .genre_database import GenreParams, ScaleType, TimeSignature, SCALE_INTERVALS, get_scale_notes

# Import all genre collections
from .rock_genres import ROCK_GENRES
from .metal_genres import METAL_GENRES
from .electronic_genres import ELECTRONIC_GENRES
from .jazz_blues_genres import JAZZ_GENRES, BLUES_GENRES
from .pop_rnb_genres import POP_GENRES, RNB_GENRES, SOUL_GENRES, FUNK_GENRES
from .hiphop_genres import HIPHOP_GENRES
from .latin_genres import LATIN_GENRES
from .world_genres import WORLD_GENRES
from .classical_genres import CLASSICAL_GENRES
from .country_folk_genres import COUNTRY_GENRES, FOLK_GENRES, GOSPEL_GENRES
from .punk_ska_genres import PUNK_GENRES, SKA_GENRES, INDUSTRIAL_GENRES
from .experimental_genres import EXPERIMENTAL_GENRES, DIGITAL_GENRES, SOVIET_RUSSIAN_GENRES

# Master genre registry
ALL_GENRES: Dict[str, GenreParams] = {}

# Combine all genre dictionaries
ALL_GENRES.update(ROCK_GENRES)
ALL_GENRES.update(METAL_GENRES)
ALL_GENRES.update(ELECTRONIC_GENRES)
ALL_GENRES.update(JAZZ_GENRES)
ALL_GENRES.update(BLUES_GENRES)
ALL_GENRES.update(POP_GENRES)
ALL_GENRES.update(RNB_GENRES)
ALL_GENRES.update(SOUL_GENRES)
ALL_GENRES.update(FUNK_GENRES)
ALL_GENRES.update(HIPHOP_GENRES)
ALL_GENRES.update(LATIN_GENRES)
ALL_GENRES.update(WORLD_GENRES)
ALL_GENRES.update(CLASSICAL_GENRES)
ALL_GENRES.update(COUNTRY_GENRES)
ALL_GENRES.update(FOLK_GENRES)
ALL_GENRES.update(GOSPEL_GENRES)
ALL_GENRES.update(PUNK_GENRES)
ALL_GENRES.update(SKA_GENRES)
ALL_GENRES.update(INDUSTRIAL_GENRES)
ALL_GENRES.update(EXPERIMENTAL_GENRES)
ALL_GENRES.update(DIGITAL_GENRES)
ALL_GENRES.update(SOVIET_RUSSIAN_GENRES)

def get_genre(genre_id: str) -> Optional[GenreParams]:
    """Get genre parameters by ID."""
    return ALL_GENRES.get(genre_id)

def list_genres() -> List[str]:
    """List all available genre IDs."""
    return list(ALL_GENRES.keys())

def list_genres_by_category() -> Dict[str, List[str]]:
    """List genres organized by category."""
    categories = {}
    for genre_id, params in ALL_GENRES.items():
        cat = params.category
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(genre_id)
    return categories

def search_genres(query: str) -> List[str]:
    """Search genres by name or description."""
    query = query.lower()
    results = []
    for genre_id, params in ALL_GENRES.items():
        if (query in genre_id.lower() or 
            query in params.name.lower() or 
            query in params.description.lower() or
            query in params.category.lower()):
            results.append(genre_id)
    return results

def get_genre_count() -> int:
    """Get total number of genres."""
    return len(ALL_GENRES)

def get_categories() -> List[str]:
    """Get list of all categories."""
    return list(set(p.category for p in ALL_GENRES.values()))

# Print summary on import
if __name__ == "__main__":
    print(f"Total genres loaded: {get_genre_count()}")
    print(f"\nCategories: {', '.join(sorted(get_categories()))}")
    print("\nGenres by category:")
    for cat, genres in sorted(list_genres_by_category().items()):
        print(f"  {cat}: {len(genres)} genres")
