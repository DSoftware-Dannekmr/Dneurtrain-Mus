"""
Classical, Orchestral, and Cinematic Music Genres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

CLASSICAL_GENRES = {
    "baroque": GenreParams(
        name="Baroque", category="Classical",
        tempo_range=(60, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(40, 90), note_density=0.6,
        syncopation=0.2, instruments=["harpsichord", "strings", "organ", "flute"],
        drum_pattern="none", bass_style="basso_continuo", chord_complexity=0.6,
        description="1600-1750, ornate counterpoint"
    ),
    "classical_period": GenreParams(
        name="Classical Period", category="Classical",
        tempo_range=(60, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(40, 100), note_density=0.5,
        syncopation=0.2, instruments=["piano", "strings", "woodwinds", "brass"],
        drum_pattern="none", bass_style="classical_bass", chord_complexity=0.5,
        description="1750-1820, balanced forms"
    ),
    "romantic": GenreParams(
        name="Romantic", category="Classical",
        tempo_range=(40, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4, TimeSignature.TS_6_8],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(30, 120), note_density=0.6,
        syncopation=0.3, instruments=["full_orchestra", "piano"],
        drum_pattern="none", bass_style="romantic_bass", chord_complexity=0.7,
        description="1820-1900, emotional expression"
    ),
    "impressionist": GenreParams(
        name="Impressionist", category="Classical",
        tempo_range=(50, 120), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.WHOLE_TONE, ScaleType.PENTATONIC_MAJOR, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(30, 80), note_density=0.5,
        syncopation=0.3, instruments=["orchestra", "harp", "woodwinds"],
        drum_pattern="none", bass_style="impressionist_bass", chord_complexity=0.8,
        description="Debussy, Ravel style"
    ),
    "modernist": GenreParams(
        name="Modernist", category="Classical",
        tempo_range=(40, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_5_4, TimeSignature.TS_7_8],
        scales=[ScaleType.CHROMATIC, ScaleType.WHOLE_TONE, ScaleType.DIMINISHED],
        swing=0.0, velocity_range=(20, 120), note_density=0.5,
        syncopation=0.5, instruments=["orchestra", "percussion"],
        drum_pattern="none", bass_style="modernist_bass", chord_complexity=0.9,
        description="20th century experimental"
    ),
    "minimalist": GenreParams(
        name="Minimalist", category="Classical",
        tempo_range=(60, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(40, 80), note_density=0.6,
        syncopation=0.3, instruments=["piano", "strings", "woodwinds", "synth"],
        drum_pattern="minimalist", bass_style="minimalist_bass", chord_complexity=0.3,
        description="Reich, Glass, Riley style"
    ),
    "neoclassical": GenreParams(
        name="Neoclassical", category="Classical",
        tempo_range=(60, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(40, 100), note_density=0.5,
        syncopation=0.2, instruments=["orchestra", "piano"],
        drum_pattern="none", bass_style="neoclassical_bass", chord_complexity=0.6,
        description="20th century classical revival"
    ),
    "contemporary_classical": GenreParams(
        name="Contemporary Classical", category="Classical",
        tempo_range=(40, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_5_4, TimeSignature.TS_7_8],
        scales=[ScaleType.CHROMATIC, ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(20, 120), note_density=0.5,
        syncopation=0.4, instruments=["orchestra", "electronics", "extended_techniques"],
        drum_pattern="none", bass_style="contemporary_bass", chord_complexity=0.8,
        description="Modern art music"
    ),
    # === CINEMATIC ===
    "film_score": GenreParams(
        name="Film Score", category="Cinematic",
        tempo_range=(40, 180), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4, TimeSignature.TS_6_8],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(20, 127), note_density=0.5,
        syncopation=0.3, instruments=["full_orchestra", "choir", "synth"],
        drum_pattern="cinematic", bass_style="cinematic_bass", chord_complexity=0.7,
        description="Hollywood orchestral"
    ),
    "epic_orchestral": GenreParams(
        name="Epic Orchestral", category="Cinematic",
        tempo_range=(80, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_6_8],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(60, 127), note_density=0.6,
        syncopation=0.3, instruments=["orchestra", "choir", "percussion", "brass"],
        drum_pattern="epic", bass_style="epic_bass", chord_complexity=0.6,
        description="Trailer music, Hans Zimmer style"
    ),
    "trailer_music": GenreParams(
        name="Trailer Music", category="Cinematic",
        tempo_range=(80, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.HARMONIC_MINOR],
        swing=0.0, velocity_range=(70, 127), note_density=0.6,
        syncopation=0.4, instruments=["orchestra", "hybrid_synth", "percussion", "choir"],
        drum_pattern="trailer", bass_style="trailer_bass", chord_complexity=0.5,
        description="Cinematic impact music"
    ),
    "ambient_score": GenreParams(
        name="Ambient Score", category="Cinematic",
        tempo_range=(40, 80), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN, ScaleType.MIXOLYDIAN],
        swing=0.0, velocity_range=(20, 60), note_density=0.2,
        syncopation=0.1, instruments=["pads", "strings", "piano", "textures"],
        drum_pattern="none", bass_style="ambient_bass", chord_complexity=0.5,
        description="Atmospheric underscore"
    ),
    "videogame_music": GenreParams(
        name="Video Game Music", category="Cinematic",
        tempo_range=(80, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.LYDIAN],
        swing=0.0, velocity_range=(50, 110), note_density=0.6,
        syncopation=0.3, instruments=["orchestra", "synth", "chiptune"],
        drum_pattern="game", bass_style="game_bass", chord_complexity=0.5,
        description="Interactive game scores"
    ),
    # === NEW AGE / MEDITATION ===
    "new_age": GenreParams(
        name="New Age", category="New Age",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.LYDIAN, ScaleType.PENTATONIC_MAJOR],
        swing=0.0, velocity_range=(30, 70), note_density=0.3,
        syncopation=0.1, instruments=["synth_pads", "piano", "flute", "harp"],
        drum_pattern="none", bass_style="new_age_bass", chord_complexity=0.4,
        description="Relaxation, meditation"
    ),
    "meditation_music": GenreParams(
        name="Meditation Music", category="New Age",
        tempo_range=(40, 70), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.PENTATONIC_MAJOR],
        swing=0.0, velocity_range=(20, 50), note_density=0.2,
        syncopation=0.0, instruments=["singing_bowls", "pads", "nature_sounds"],
        drum_pattern="none", bass_style="drone", chord_complexity=0.3,
        description="Mindfulness, healing"
    ),
    "space_music": GenreParams(
        name="Space Music", category="New Age",
        tempo_range=(40, 80), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.LYDIAN, ScaleType.WHOLE_TONE],
        swing=0.0, velocity_range=(20, 60), note_density=0.2,
        syncopation=0.1, instruments=["synth_pads", "textures", "drones"],
        drum_pattern="none", bass_style="space_drone", chord_complexity=0.5,
        description="Cosmic, ethereal"
    ),
}
