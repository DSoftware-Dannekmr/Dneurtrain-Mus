"""
Country, Folk, Gospel, and Americana Genres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

COUNTRY_GENRES = {
    "country": GenreParams(
        name="Country", category="Country",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN, ScaleType.PENTATONIC_MAJOR],
        swing=0.2, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["acoustic_guitar", "steel_guitar", "fiddle", "bass", "drums"],
        drum_pattern="country", bass_style="country_bass", chord_complexity=0.3,
        description="American country music"
    ),
    "bluegrass": GenreParams(
        name="Bluegrass", category="Country",
        tempo_range=(100, 200), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN, ScaleType.DORIAN],
        swing=0.2, velocity_range=(60, 100), note_density=0.7,
        syncopation=0.4, instruments=["banjo", "mandolin", "fiddle", "guitar", "bass"],
        drum_pattern="none", bass_style="bluegrass_bass", chord_complexity=0.4,
        description="Appalachian acoustic"
    ),
    "honky_tonk": GenreParams(
        name="Honky Tonk", category="Country",
        tempo_range=(100, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.3, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.3, instruments=["piano", "steel_guitar", "fiddle", "bass", "drums"],
        drum_pattern="honky_tonk", bass_style="honky_tonk_bass", chord_complexity=0.3,
        description="Barroom country"
    ),
    "outlaw_country": GenreParams(
        name="Outlaw Country", category="Country",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "bass", "drums", "piano"],
        drum_pattern="outlaw", bass_style="outlaw_bass", chord_complexity=0.3,
        description="Anti-Nashville, 70s"
    ),
    "country_pop": GenreParams(
        name="Country Pop", category="Country",
        tempo_range=(90, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR],
        swing=0.1, velocity_range=(60, 95), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "synth", "bass", "drums"],
        drum_pattern="country_pop", bass_style="country_pop_bass", chord_complexity=0.3,
        description="Crossover country"
    ),
    "country_rock": GenreParams(
        name="Country Rock", category="Country",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(70, 110), note_density=0.6,
        syncopation=0.3, instruments=["electric_guitar", "pedal_steel", "bass", "drums"],
        drum_pattern="country_rock", bass_style="country_rock_bass", chord_complexity=0.3,
        description="Rock meets country"
    ),
    "americana": GenreParams(
        name="Americana", category="Country",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.3, instruments=["acoustic_guitar", "mandolin", "bass", "drums"],
        drum_pattern="americana", bass_style="americana_bass", chord_complexity=0.4,
        description="Roots music blend"
    ),
    "alt_country": GenreParams(
        name="Alt-Country", category="Country",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(50, 95), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "pedal_steel", "bass", "drums"],
        drum_pattern="alt_country", bass_style="alt_country_bass", chord_complexity=0.4,
        description="Alternative country"
    ),
    "western_swing": GenreParams(
        name="Western Swing", category="Country",
        tempo_range=(120, 180), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MIXOLYDIAN],
        swing=0.5, velocity_range=(60, 100), note_density=0.6,
        syncopation=0.4, instruments=["steel_guitar", "fiddle", "piano", "bass", "drums"],
        drum_pattern="western_swing", bass_style="swing_bass", chord_complexity=0.5,
        description="Jazz-influenced country"
    ),
}

FOLK_GENRES = {
    "folk": GenreParams(
        name="Folk", category="Folk",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.1, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.2, instruments=["acoustic_guitar", "harmonica", "banjo"],
        drum_pattern="none", bass_style="folk_bass", chord_complexity=0.3,
        description="Traditional acoustic"
    ),
    "folk_rock": GenreParams(
        name="Folk Rock", category="Folk",
        tempo_range=(100, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR, ScaleType.MIXOLYDIAN],
        swing=0.1, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["acoustic_guitar", "electric_guitar", "bass", "drums"],
        drum_pattern="folk_rock", bass_style="folk_rock_bass", chord_complexity=0.4,
        description="Electric folk"
    ),
    "indie_folk": GenreParams(
        name="Indie Folk", category="Folk",
        tempo_range=(80, 130), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(40, 80), note_density=0.4,
        syncopation=0.2, instruments=["acoustic_guitar", "banjo", "ukulele", "strings"],
        drum_pattern="indie_folk", bass_style="indie_folk_bass", chord_complexity=0.4,
        description="Modern acoustic indie"
    ),
    "chamber_folk": GenreParams(
        name="Chamber Folk", category="Folk",
        tempo_range=(60, 120), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.0, velocity_range=(30, 70), note_density=0.4,
        syncopation=0.2, instruments=["strings", "acoustic_guitar", "piano", "woodwinds"],
        drum_pattern="none", bass_style="chamber_bass", chord_complexity=0.5,
        description="Orchestral folk"
    ),
    "neofolk": GenreParams(
        name="Neofolk", category="Folk",
        tempo_range=(60, 100), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.0, velocity_range=(30, 70), note_density=0.3,
        syncopation=0.2, instruments=["acoustic_guitar", "piano", "strings", "percussion"],
        drum_pattern="neofolk", bass_style="neofolk_bass", chord_complexity=0.4,
        description="Dark acoustic folk"
    ),
    "appalachian": GenreParams(
        name="Appalachian", category="Folk",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN, ScaleType.MAJOR],
        swing=0.2, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.3, instruments=["banjo", "fiddle", "dulcimer", "guitar"],
        drum_pattern="none", bass_style="appalachian_bass", chord_complexity=0.3,
        description="Mountain music"
    ),
    "old_time": GenreParams(
        name="Old-Time", category="Folk",
        tempo_range=(100, 160), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_2_4],
        scales=[ScaleType.MAJOR, ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.2, velocity_range=(60, 95), note_density=0.6,
        syncopation=0.3, instruments=["fiddle", "banjo", "guitar"],
        drum_pattern="none", bass_style="old_time_bass", chord_complexity=0.2,
        description="Pre-bluegrass American"
    ),
}

GOSPEL_GENRES = {
    "gospel": GenreParams(
        name="Gospel", category="Gospel",
        tempo_range=(60, 140), time_signatures=[TimeSignature.TS_4_4, TimeSignature.TS_3_4],
        scales=[ScaleType.MAJOR, ScaleType.PENTATONIC_MAJOR],
        swing=0.3, velocity_range=(60, 120), note_density=0.5,
        syncopation=0.4, instruments=["piano", "organ", "bass", "drums", "choir"],
        drum_pattern="gospel", bass_style="gospel_bass", chord_complexity=0.5,
        description="African American church music"
    ),
    "southern_gospel": GenreParams(
        name="Southern Gospel", category="Gospel",
        tempo_range=(80, 140), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR],
        swing=0.2, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.3, instruments=["piano", "guitar", "bass", "drums"],
        drum_pattern="southern_gospel", bass_style="southern_gospel_bass", chord_complexity=0.4,
        description="White Southern church"
    ),
    "contemporary_christian": GenreParams(
        name="Contemporary Christian", category="Gospel",
        tempo_range=(70, 130), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MAJOR, ScaleType.MINOR],
        swing=0.1, velocity_range=(50, 95), note_density=0.5,
        syncopation=0.3, instruments=["guitar", "synth", "bass", "drums"],
        drum_pattern="ccm", bass_style="ccm_bass", chord_complexity=0.4,
        description="Modern worship music"
    ),
    "urban_gospel": GenreParams(
        name="Urban Gospel", category="Gospel",
        tempo_range=(70, 110), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.2, velocity_range=(60, 100), note_density=0.5,
        syncopation=0.5, instruments=["keys", "bass", "drums", "choir"],
        drum_pattern="urban_gospel", bass_style="urban_gospel_bass", chord_complexity=0.6,
        description="R&B influenced gospel"
    ),
    "spirituals": GenreParams(
        name="Spirituals", category="Gospel",
        tempo_range=(50, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.PENTATONIC_MINOR, ScaleType.MINOR],
        swing=0.3, velocity_range=(40, 90), note_density=0.4,
        syncopation=0.4, instruments=["choir", "piano"],
        drum_pattern="none", bass_style="spiritual_bass", chord_complexity=0.3,
        description="African American sacred songs"
    ),
}
