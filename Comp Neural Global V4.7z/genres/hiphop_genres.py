"""
Hip-Hop and Rap Genres
"""
from .genre_database import GenreParams, TimeSignature, ScaleType

HIPHOP_GENRES = {
    "hip_hop": GenreParams(
        name="Hip-Hop", category="Hip-Hop",
        tempo_range=(85, 115), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.5, instruments=["drums", "bass", "samples", "synth"],
        drum_pattern="boom_bap", bass_style="hip_hop_bass", chord_complexity=0.3,
        description="Sample-based, rhythmic vocals"
    ),
    "old_school_hip_hop": GenreParams(
        name="Old School Hip-Hop", category="Hip-Hop",
        tempo_range=(95, 115), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.3, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.4, instruments=["drums", "bass", "turntables"],
        drum_pattern="old_school", bass_style="old_school_bass", chord_complexity=0.2,
        description="80s hip-hop, party vibes"
    ),
    "boom_bap": GenreParams(
        name="Boom Bap", category="Hip-Hop",
        tempo_range=(85, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.3, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.5, instruments=["drums", "bass", "samples"],
        drum_pattern="boom_bap", bass_style="boom_bap_bass", chord_complexity=0.3,
        description="Classic East Coast sound"
    ),
    "gangsta_rap": GenreParams(
        name="Gangsta Rap", category="Hip-Hop",
        tempo_range=(85, 105), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.2, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.5, instruments=["drums", "bass", "synth", "samples"],
        drum_pattern="g_funk", bass_style="g_funk_bass", chord_complexity=0.3,
        description="West Coast, G-funk influenced"
    ),
    "trap": GenreParams(
        name="Trap", category="Hip-Hop",
        tempo_range=(130, 170), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 120), note_density=0.6,
        syncopation=0.6, instruments=["808", "hi_hats", "synth"],
        drum_pattern="trap", bass_style="808_bass", chord_complexity=0.2,
        description="808s, hi-hat rolls, dark"
    ),
    "drill": GenreParams(
        name="Drill", category="Hip-Hop",
        tempo_range=(135, 145), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.6, instruments=["808", "hi_hats", "dark_synth"],
        drum_pattern="drill", bass_style="drill_bass", chord_complexity=0.2,
        description="Chicago/UK drill, sliding 808s"
    ),
    "conscious_rap": GenreParams(
        name="Conscious Rap", category="Hip-Hop",
        tempo_range=(80, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.3, velocity_range=(60, 90), note_density=0.5,
        syncopation=0.4, instruments=["drums", "bass", "samples", "live_instruments"],
        drum_pattern="conscious", bass_style="conscious_bass", chord_complexity=0.5,
        description="Socially aware, lyrical"
    ),
    "jazz_rap": GenreParams(
        name="Jazz Rap", category="Hip-Hop",
        tempo_range=(80, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.DORIAN, ScaleType.MIXOLYDIAN],
        swing=0.4, velocity_range=(50, 90), note_density=0.5,
        syncopation=0.5, instruments=["drums", "bass", "jazz_samples", "horns"],
        drum_pattern="jazz_rap", bass_style="jazz_hip_hop", chord_complexity=0.6,
        description="Jazz-influenced hip-hop"
    ),
    "lofi_hip_hop": GenreParams(
        name="Lo-fi Hip-Hop", category="Hip-Hop",
        tempo_range=(70, 90), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.DORIAN],
        swing=0.3, velocity_range=(40, 75), note_density=0.4,
        syncopation=0.4, instruments=["drums", "bass", "samples", "vinyl_crackle"],
        drum_pattern="lofi", bass_style="lofi_bass", chord_complexity=0.5,
        description="Chill, nostalgic, study beats"
    ),
    "horrorcore": GenreParams(
        name="Horrorcore", category="Hip-Hop",
        tempo_range=(80, 100), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN, ScaleType.LOCRIAN],
        swing=0.2, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.5, instruments=["drums", "bass", "dark_samples", "synth"],
        drum_pattern="horrorcore", bass_style="dark_bass", chord_complexity=0.3,
        description="Dark, horror-themed"
    ),
    "crunk": GenreParams(
        name="Crunk", category="Hip-Hop",
        tempo_range=(130, 150), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(90, 120), note_density=0.6,
        syncopation=0.4, instruments=["808", "synth", "chants"],
        drum_pattern="crunk", bass_style="crunk_bass", chord_complexity=0.2,
        description="Southern, energetic, chants"
    ),
    "cloud_rap": GenreParams(
        name="Cloud Rap", category="Hip-Hop",
        tempo_range=(60, 80), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.MAJOR],
        swing=0.1, velocity_range=(40, 80), note_density=0.3,
        syncopation=0.4, instruments=["synth_pads", "drums", "reverb"],
        drum_pattern="cloud", bass_style="cloud_bass", chord_complexity=0.4,
        description="Dreamy, atmospheric, spacey"
    ),
    "phonk": GenreParams(
        name="Phonk", category="Hip-Hop",
        tempo_range=(130, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.5,
        syncopation=0.5, instruments=["cowbell", "808", "memphis_samples"],
        drum_pattern="phonk", bass_style="phonk_bass", chord_complexity=0.2,
        description="Memphis revival, cowbells"
    ),
    "uk_grime": GenreParams(
        name="UK Grime", category="Hip-Hop",
        tempo_range=(138, 142), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PHRYGIAN],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.5, instruments=["synth", "drums", "bass"],
        drum_pattern="grime", bass_style="grime_bass", chord_complexity=0.3,
        description="UK electronic hip-hop"
    ),
    "afrotrap": GenreParams(
        name="Afrotrap", category="Hip-Hop",
        tempo_range=(100, 120), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR, ScaleType.PENTATONIC_MINOR],
        swing=0.2, velocity_range=(70, 100), note_density=0.6,
        syncopation=0.6, instruments=["drums", "bass", "african_percussion"],
        drum_pattern="afrotrap", bass_style="afro_bass", chord_complexity=0.3,
        description="African rhythms meet trap"
    ),
    "latin_trap": GenreParams(
        name="Latin Trap", category="Hip-Hop",
        tempo_range=(130, 160), time_signatures=[TimeSignature.TS_4_4],
        scales=[ScaleType.MINOR],
        swing=0.0, velocity_range=(80, 110), note_density=0.6,
        syncopation=0.5, instruments=["808", "hi_hats", "latin_percussion"],
        drum_pattern="latin_trap", bass_style="latin_808", chord_complexity=0.2,
        description="Spanish trap, reggaeton influenced"
    ),
}
